# Complaint Handling System - Complete Function Inventory

This document provides a comprehensive, rigorous inventory of all **29 application function definitions** implemented in the Complaint Handling System (`cchhss`).

Every function in this inventory corresponds to an actual, distinct function definition in [`src/main.c`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c) and is declared in [`include/complaint_system.h`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/include/complaint_system.h). Test functions, test fixtures, test helpers, and standard C library functions are excluded.

---

## Summary of Inventory Verification

- **Total Distinct Application Function Declarations:** 29 (in `include/complaint_system.h`, lines 94–122)
- **Total Distinct Application Function Definitions:** 29 (in `src/main.c`, lines 34–1426)
- **Function Count Invariant:** Strictly 29 application functions.

---

## Detailed Function Specifications (1 – 29)

### 1. `getTimestamp`
- **Function Number:** 1
- **Source File & Line:** [`src/main.c#L34`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L34)
- **Purpose:** Formats the current system wall-clock time into a standard timestamp string (`YYYY-MM-DD HH:MM:SS`).
- **Input Parameters:**
  - `char *buffer`: Destination buffer pointer. Valid range: Non-null pointer to writable memory buffer.
  - `size_t size`: Size of the destination buffer in bytes. Valid range: `size >= 20` to hold the complete timestamp with null terminator; values `size > 0` are handled safely.
- **Return Type & Output:** `void`.
- **Side Effects:** Writes formatted string into `buffer`. No heap allocations or global state modifications.
- **Conditions & Edge Cases:**
  - *Normal:* `buffer` valid, `size >= 20`, fills buffer with `YYYY-MM-DD HH:MM:SS`.
  - *Boundary:* `size == 0` (early return without writing); `size == 1` (stores empty string or truncates); `size == 20` (exact fit).
  - *Error / Exceptional:* `buffer == NULL` (early return, no crash); `localtime()` returning `NULL` falls back to writing `"N/A"`.

---

### 2. `readString`
- **Function Number:** 2
- **Source File & Line:** [`src/main.c#L49`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L49)
- **Purpose:** Prompts the user, reads a single line from standard input (`stdin`), strips trailing newline characters (`\r`, `\n`), and sanitizes input by replacing pipe delimiter characters (`|`) with hyphens (`-`) to preserve database file delimiter integrity.
- **Input Parameters:**
  - `const char *prompt`: Message displayed before reading input. Valid range: Valid string pointer or `NULL` / empty `""`.
  - `char *buffer`: Target buffer. Valid range: Non-null pointer to writable char array.
  - `size_t size`: Capacity of buffer. Valid range: `size > 0`.
- **Return Type & Output:** `void`.
- **Side Effects:** Emits prompt to `stdout`; consumes characters from `stdin`; mutates `buffer`.
- **Conditions & Edge Cases:**
  - *Normal:* Reads standard alphanumeric line, strips trailing `\n`, replaces any `|` with `-`.
  - *Boundary:* `buffer == NULL` or `size == 0` (immediate no-op); `size == 1` (reads at most 0 characters, stores null terminator).
  - *Error / Exceptional:* EOF encountered on `stdin` (`buffer[0] = '\0'`); prompt is `NULL` or empty string (skips prompt output without error); input contains multiple trailing `\r` and `\n` characters (all stripped cleanly); input contains embedded pipes `A|B|C` transformed into `A-B-C`.

---

### 3. `readInt`
- **Function Number:** 3
- **Source File & Line:** [`src/main.c#L79`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L79)
- **Purpose:** Robustly reads and validates an integer from user input within a specified closed interval `[minVal, maxVal]`, reprompting in a loop on invalid or out-of-range input, with EOF recovery.
- **Input Parameters:**
  - `const char *prompt`: Prompt text. Valid range: Valid string or `NULL`.
  - `int minVal`: Minimum acceptable integer. Valid range: Any valid `int` such that `minVal <= maxVal`.
  - `int maxVal`: Maximum acceptable integer. Valid range: Any valid `int` such that `maxVal >= minVal`.
- **Return Type & Output:** `int`. Returns parsed integer guaranteed to be in `[minVal, maxVal]`.
- **Side Effects:** Writes prompts and error messages to `stdout`; reads from `stdin`.
- **Conditions & Edge Cases:**
  - *Normal:* User enters valid digits within range on first try; returns integer.
  - *Boundary:* User enters exactly `minVal` or exactly `maxVal`.
  - *Error / Exceptional:* Empty input line followed by non-empty valid number; input containing non-numeric characters (`"abc"`, `"12abc"`, `"--5"`); integer below `minVal` or above `maxVal`; EOF on `stdin` returns `minVal` to break infinite looping.

---

### 4. `findCustomerByUsername`
- **Function Number:** 4
- **Source File & Line:** [`src/main.c#L106`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L106)
- **Purpose:** Traverses the singly linked list of registered customers to find an account matching the given username.
- **Input Parameters:**
  - `const char *username`: Unique username string to look up. Valid range: Non-null, non-empty C-string.
- **Return Type & Output:** `CustomerNode*`. Pointer to matching customer node, or `NULL` if not found.
- **Side Effects:** Traverses in-memory customer linked list. No state mutations.
- **Conditions & Edge Cases:**
  - *Normal:* Target username exists in list; returns valid node pointer.
  - *Boundary:* Target is first element (head); target is last element in multi-node list.
  - *Error / Exceptional:* `username == NULL` or `username[0] == '\0'` (returns `NULL`); empty customer list (`customerHead == NULL`); non-existent username; case-sensitive mismatch.

---

### 5. `findComplaintById`
- **Function Number:** 5
- **Source File & Line:** [`src/main.c#L122`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L122)
- **Purpose:** Traverses the singly linked list of complaints to locate a ticket by its unique identifier (e.g., `CMP101`).
- **Input Parameters:**
  - `const char *complaintId`: Complaint ID string. Valid range: Non-null, non-empty string.
- **Return Type & Output:** `ComplaintNode*`. Pointer to matching complaint node, or `NULL` if not found.
- **Side Effects:** Traverses in-memory complaint linked list. No state mutations.
- **Conditions & Edge Cases:**
  - *Normal:* Complaint ID exists; returns matching node pointer.
  - *Boundary:* Target is at head; target is at tail of list.
  - *Error / Exceptional:* `complaintId == NULL` or `complaintId[0] == '\0'` (returns `NULL`); empty complaint list (`complaintHead == NULL`); ID not in list; case sensitivity.

---

### 6. `addAuditEntry`
- **Function Number:** 6
- **Source File & Line:** [`src/main.c#L138`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L138)
- **Purpose:** Allocates a new `AuditNode` and appends it to the end of a complaint's chronological audit trail linked list.
- **Input Parameters:**
  - `ComplaintNode *node`: Pointer to target complaint node. Valid range: Non-null pointer.
  - `const char *action`: Action name (e.g., `"REGISTERED"`, `"ASSIGNED"`). Valid range: String or `NULL`.
  - `const char *by`: Identifier or role of actor performing the action. Valid range: String or `NULL`.
  - `const char *details`: Descriptive explanation of event. Valid range: String or `NULL`.
- **Return Type & Output:** `void`.
- **Side Effects:** Dynamically allocates heap memory (`sizeof(AuditNode)`); updates `node->auditHead` or appends to tail; captures current timestamp.
- **Conditions & Edge Cases:**
  - *Normal:* Appends entry with all valid string fields.
  - *Boundary:* Appending to complaint with empty audit trail (`auditHead == NULL`); appending multiple entries sequentially.
  - *Error / Exceptional:* `node == NULL` (early return); `action == NULL` (defaults to `"ACTION"`); `by == NULL` (defaults to `"SYSTEM"`); `details == NULL` (defaults to `""`); failed `malloc()` (handles null gracefully with error print).

---

### 7. `autoAssignAgent`
- **Function Number:** 7
- **Source File & Line:** [`src/main.c#L168`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L168)
- **Purpose:** Selects the active support agent with the lowest open workload (tickets not in `RESOLVED` or `CLOSED` status) for optimal ticket distribution.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `int`. Array index of selected agent in `[0, MAX_AGENTS - 1]`, or `-1` if no agents are active.
- **Side Effects:** Reads global `agents` array and traverses `complaintHead` list.
- **Conditions & Edge Cases:**
  - *Normal:* Multiple active agents with varying workloads; returns index of agent with minimal active tickets.
  - *Boundary:* All agents have zero workload (returns first active agent index `0`); single active agent; agents having only `RESOLVED` or `CLOSED` tickets (workload treated as 0).
  - *Error / Exceptional:* All agents marked inactive (`isActive == 0`); returns `-1`.

---

### 8. `initSystem`
- **Function Number:** 8
- **Source File & Line:** [`src/main.c#L200`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L200)
- **Purpose:** Ensures the `data/` directory exists, initializes the 10 predefined support agents (from disk or defaults), loads persistent counters (`counters.txt`), customer accounts (`customers.txt`), complaints (`complaints.txt`), and connects all historical audit records (`audit_log.txt`).
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Creates `data` directory; opens and reads files; allocates customer, complaint, and audit nodes; initializes global state (`customerHead`, `complaintHead`, `agents`, `nextComplaintNum`, `nextCustomerNum`).
- **Conditions & Edge Cases:**
  - *Normal:* Data files exist with valid pipe-delimited records; loads all entities into memory.
  - *Boundary:* Clean system with missing data files; initializes 10 default agents, sets counters to 101/1001, leaves linked lists empty.
  - *Error / Exceptional:* Missing or corrupt `counters.txt` resets counters to `>= 101` and `>= 1001`; partially filled `agents.txt` (less than 10 lines) populates remaining slots with default agents; malformed lines in `customers.txt` or `complaints.txt` skipped; audit logs referencing non-existent complaint IDs skipped cleanly.

---

### 9. `saveAllData`
- **Function Number:** 9
- **Source File & Line:** [`src/main.c#L379`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L379)
- **Purpose:** Persists all in-memory system state to disk in pipe-delimited text format: `data/counters.txt`, `data/agents.txt`, `data/customers.txt`, `data/complaints.txt`, and `data/audit_log.txt`.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Writes and overwrites files in `data/` folder.
- **Conditions & Edge Cases:**
  - *Normal:* Writes all active entities and counters to disk.
  - *Boundary:* Empty lists (0 customers, 0 complaints, 0 audits); creates empty data files with valid counters and agent table.
  - *Error / Exceptional:* Complaints with missing/blank timestamps or notes default to `"N/A"` or `"No notes yet"`; verifies file handles before writing.

---

### 10. `freeAllMemory`
- **Function Number:** 10
- **Source File & Line:** [`src/main.c#L456`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L456)
- **Purpose:** Traverses and deallocates all dynamic heap memory allocated for the customer list, complaint list, and nested audit linked lists, preventing memory leaks and resetting heads to `NULL`.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Releases heap memory; resets `customerHead = NULL` and `complaintHead = NULL`.
- **Conditions & Edge Cases:**
  - *Normal:* Deallocates populated customer list, complaints list, and all attached audit trails.
  - *Boundary:* Called when system is already empty (`customerHead == NULL`, `complaintHead == NULL`); completes without error.
  - *Error / Exceptional:* Called repeatedly in succession (idempotent); handles complaints with zero audit entries without crashing.

---

### 11. `customerMenu`
- **Function Number:** 11
- **Source File & Line:** [`src/main.c#L484`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L484)
- **Purpose:** Interactive customer portal entry menu presenting options to register a new account, log in, or return to the main menu.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; delegates to `customerRegister()` or `customerLogin()`.
- **Conditions & Edge Cases:**
  - *Normal:* Option 1 calls `customerRegister()`, option 2 calls `customerLogin()`, option 3 exits loop.
  - *Boundary:* Immediate selection of option 3 returns cleanly.
  - *Error / Exceptional:* Invalid menu input reprompted by `readInt()`.

---

### 12. `customerRegister`
- **Function Number:** 12
- **Source File & Line:** [`src/main.c#L508`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L508)
- **Purpose:** Gathers full name, username, password, and contact info, validates inputs, prevents duplicate usernames, allocates a new customer record with an auto-incremented ID (`CUST1001+`), and saves data to disk.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; dynamically allocates `CustomerNode`; appends to `customerHead`; calls `saveAllData()`; increments `nextCustomerNum`.
- **Conditions & Edge Cases:**
  - *Normal:* Valid, unique customer credentials registered successfully.
  - *Boundary:* First customer in empty list (`customerHead == NULL`); appending to existing list.
  - *Error / Exceptional:* Blank full name, blank username, blank password, or blank contact detail aborts registration without creating accounts; duplicate username aborts registration; memory allocation failure handled safely.

---

### 13. `customerLogin`
- **Function Number:** 13
- **Source File & Line:** [`src/main.c#L573`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L573)
- **Purpose:** Prompts for username and password, authenticates credentials against the customer list, and on success launches `customerDashboard()`.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; launches customer session on successful authentication.
- **Conditions & Edge Cases:**
  - *Normal:* Correct username and password opens dashboard.
  - *Boundary:* Case-sensitive username and password matching.
  - *Error / Exceptional:* Non-existent username; correct username with incorrect password; empty username or password input.

---

### 14. `customerDashboard`
- **Function Number:** 14
- **Source File & Line:** [`src/main.c#L593`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L593)
- **Purpose:** Main navigation dashboard for authenticated customers: register complaint, view complaints, track complaint, view audit history, or logout.
- **Input Parameters:**
  - `const char *customerId`: Authenticated customer identifier (e.g., `"CUST1001"`).
  - `const char *customerName`: Customer's full name.
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; invokes customer service operations.
- **Conditions & Edge Cases:**
  - *Normal:* Navigates options 1–4 and exits on option 5.
  - *Boundary:* Immediate logout on option 5.
  - *Error / Exceptional:* Invalid menu selections filtered by `readInt()`.

---

### 15. `customerRegisterComplaint`
- **Function Number:** 15
- **Source File & Line:** [`src/main.c#L624`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L624)
- **Purpose:** Allows customer to choose complaint category and priority, provide description, generates sequential complaint ID starting strictly at `CMP101`, auto-assigns an active agent, records audit trail, and persists changes.
- **Input Parameters:**
  - `const char *customerId`: Owner's customer identifier.
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; allocates `ComplaintNode`; adds audit entries; appends to `complaintHead`; increments `nextComplaintNum`; calls `saveAllData()`.
- **Conditions & Edge Cases:**
  - *Normal:* Valid category (1–5), priority (1–4), and description creates ticket; assigned to least loaded agent.
  - *Boundary:* Active agents exist (ticket status becomes `ASSIGNED`); no active agents exist (ticket status remains `PENDING` and assigned to `UNASSIGNED`).
  - *Error / Exceptional:* Empty description aborts registration; ID collision avoidance increments `nextComplaintNum` until a free ID is found; allocation failure handled safely.

---

### 16. `customerViewComplaints`
- **Function Number:** 16
- **Source File & Line:** [`src/main.c#L731`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L731)
- **Purpose:** Displays a tabular summary of all complaints lodged by the authenticated customer.
- **Input Parameters:**
  - `const char *customerId`: Authenticated customer ID.
- **Return Type & Output:** `void`.
- **Side Effects:** Prints table to `stdout`.
- **Conditions & Edge Cases:**
  - *Normal:* Customer has one or more complaints; prints all matching records.
  - *Boundary:* Customer has exactly zero complaints; prints `"No complaints found under your account."`.
  - *Error / Exceptional:* System has complaints belonging to other customers; confirms none are leaked.

---

### 17. `customerTrackComplaint`
- **Function Number:** 17
- **Source File & Line:** [`src/main.c#L765`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L765)
- **Purpose:** Prompts for complaint ID, verifies customer ownership, and prints a comprehensive tracking card showing progress timestamps and stage progression.
- **Input Parameters:**
  - `const char *customerId`: Requesting customer's ID.
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O.
- **Conditions & Edge Cases:**
  - *Normal:* Valid owned complaint displays all details and stage progression (`PENDING`, `ASSIGNED`, `IN_PROGRESS`, `ESCALATED`, `RESOLVED`, `CLOSED`).
  - *Boundary:* Complaint in unknown custom status displays fallback text.
  - *Error / Exceptional:* Complaint ID does not exist; complaint belongs to a different customer (security violation reported; access denied).

---

### 18. `customerViewHistory`
- **Function Number:** 18
- **Source File & Line:** [`src/main.c#L823`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L823)
- **Purpose:** Prompts for complaint ID, verifies ownership, and displays the chronological audit trail entries for the ticket.
- **Input Parameters:**
  - `const char *customerId`: Requesting customer ID.
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O.
- **Conditions & Edge Cases:**
  - *Normal:* Displays chronological audit log table for owned complaint.
  - *Boundary:* Owned complaint with zero audit records prints `"No audit records found"`.
  - *Error / Exceptional:* Non-existent complaint ID; attempting to view another customer's complaint audit history (security violation; access denied).

---

### 19. `agentMenu`
- **Function Number:** 19
- **Source File & Line:** [`src/main.c#L861`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L861)
- **Purpose:** Pre-login portal menu for support agents: authenticate credentials and launch agent dashboard, or return to main menu.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; validates agent status; launches `agentDashboard()`.
- **Conditions & Edge Cases:**
  - *Normal:* Valid active agent username and password opens dashboard.
  - *Boundary:* Option 2 immediately returns to main menu.
  - *Error / Exceptional:* Invalid username or password; authenticating as an agent whose account is currently inactive (`isActive == 0`) denies access with message.

---

### 20. `agentDashboard`
- **Function Number:** 20
- **Source File & Line:** [`src/main.c#L905`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L905)
- **Purpose:** Operational dashboard for logged-in support agent: view assigned complaints, update ticket status, view audit history, or logout.
- **Input Parameters:**
  - `int agentIdx`: Index of logged-in agent in `agents` array. Valid range: `[0, MAX_AGENTS - 1]`.
- **Return Type & Output:** `void`.
- **Side Effects:** Computes current active workload; console I/O; routes agent operations.
- **Conditions & Edge Cases:**
  - *Normal:* Navigates options 1–3 and logs out on option 4.
  - *Boundary:* Workload calculation properly excludes `RESOLVED` and `CLOSED` complaints.
  - *Error / Exceptional:* History option for missing complaint ID shows error; history for existing complaint displays complete audit trail.

---

### 21. `agentViewAssigned`
- **Function Number:** 21
- **Source File & Line:** [`src/main.c#L961`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L961)
- **Purpose:** Lists all complaints currently assigned to the given agent ID.
- **Input Parameters:**
  - `const char *agentId`: Support agent ID (e.g., `"AGT101"`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console output.
- **Conditions & Edge Cases:**
  - *Normal:* Displays formatted table of all tickets assigned to this agent.
  - *Boundary:* Zero complaints assigned prints `"No complaints are currently assigned to you."`.
  - *Error / Exceptional:* Does not display complaints assigned to other agents.

---

### 22. `agentUpdateComplaint`
- **Function Number:** 22
- **Source File & Line:** [`src/main.c#L995`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L995)
- **Purpose:** Allows agent to update status of an assigned ticket to `IN_PROGRESS`, `RESOLVED`, or `ESCALATED`, update timestamps, increment resolved counters, append an audit entry, and persist data.
- **Input Parameters:**
  - `const char *agentId`: Logged-in agent's ID.
- **Return Type & Output:** `void`.
- **Side Effects:** Mutates `Complaint` fields; appends `AuditNode`; increments `agents[i].resolvedCount` on resolution; calls `saveAllData()`.
- **Conditions & Edge Cases:**
  - *Normal:* Updates ticket to `IN_PROGRESS`, `RESOLVED`, or `ESCALATED` with custom note; persists changes.
  - *Boundary:* Action cancelled (choice 4); empty progress note defaults to `"Status updated by <agentId>"`.
  - *Error / Exceptional:* Complaint ID not found; complaint is assigned to a different agent (error reported; modification blocked).

---

### 23. `managerMenu`
- **Function Number:** 23
- **Source File & Line:** [`src/main.c#L1064`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1064)
- **Purpose:** Entry portal for operations manager: authenticates credentials and launches administrative dashboard.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; launches `managerDashboard()`.
- **Conditions & Edge Cases:**
  - *Normal:* Valid manager credentials (`manager` / `manager123`) grants access.
  - *Boundary:* Option 2 returns to main menu.
  - *Error / Exceptional:* Invalid manager username or password denies access.

---

### 24. `managerDashboard`
- **Function Number:** 24
- **Source File & Line:** [`src/main.c#L1096`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1096)
- **Purpose:** Administrative operations dashboard: view metrics & complaints, assign/reassign complaints, update status/close/escalate, manage agents, view system-wide audit trail, or logout.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Console I/O; routes administrative commands.
- **Conditions & Edge Cases:**
  - *Normal:* Options 1–5 execute sub-modules; option 6 logs out.
  - *Boundary:* Option 5 when system audit log is empty vs populated.
  - *Error / Exceptional:* Option 6 terminates session cleanly.

---

### 25. `managerViewAllComplaints`
- **Function Number:** 25
- **Source File & Line:** [`src/main.c#L1150`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1150)
- **Purpose:** Computes breakdown of complaint counts by status (`PENDING`, `ASSIGNED`, `IN_PROGRESS`, `ESCALATED`, `RESOLVED`, `CLOSED`), displays metrics dashboard, and lists every complaint in the system.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Computes metrics; prints dashboard and table to `stdout`.
- **Conditions & Edge Cases:**
  - *Normal:* Correctly tallies and displays complaints of all statuses.
  - *Boundary:* Zero complaints in system displays zero metrics and `"Zero complaints exist in the system."`.
  - *Error / Exceptional:* Handles complaints in any combination of statuses.

---

### 26. `managerAssignComplaint`
- **Function Number:** 26
- **Source File & Line:** [`src/main.c#L1200`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1200)
- **Purpose:** Allows manager to assign or reassign a complaint to any active agent, displays agent workloads, updates timestamps and status (e.g., `PENDING` -> `ASSIGNED`), logs audit entry, and saves data.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Updates `node->data.assignedAgentId`, `timestamps.assigned`, and `status`; appends `AuditNode`; calls `saveAllData()`.
- **Conditions & Edge Cases:**
  - *Normal:* Assigns complaint to chosen active agent; updates status if previously `PENDING`.
  - *Boundary:* Reassigning ticket already `IN_PROGRESS` or `RESOLVED` retains status while reassigning agent.
  - *Error / Exceptional:* Complaint ID not found; target agent ID does not exist; target agent is inactive (reassignment aborted).

---

### 27. `managerUpdateComplaint`
- **Function Number:** 27
- **Source File & Line:** [`src/main.c#L1277`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1277)
- **Purpose:** Grants manager authority to set status to `IN_PROGRESS`, `RESOLVED`, `CLOSED`, or `ESCALATED`, records corresponding timestamps, appends audit trail, and saves data.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Mutates status and timestamps; appends audit node; calls `saveAllData()`.
- **Conditions & Edge Cases:**
  - *Normal:* Successfully transitions status to any of the 4 states with custom note.
  - *Boundary:* Option 5 cancels action; empty note defaults to `"Status updated by Manager"`.
  - *Error / Exceptional:* Complaint ID not found; invalid menu selections reprompted.

---

### 28. `managerAgentManagement`
- **Function Number:** 28
- **Source File & Line:** [`src/main.c#L1340`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1340)
- **Purpose:** Displays table of all 10 support agents with workload, resolved count, and status (`ACTIVE`/`INACTIVE`), and allows toggling an agent's active status. Passwords are deliberately omitted for security.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `void`.
- **Side Effects:** Toggles `agents[i].isActive`; calls `saveAllData()`.
- **Conditions & Edge Cases:**
  - *Normal:* Toggles active agent to inactive, or inactive to active; persists state.
  - *Boundary:* Option 2 returns to manager menu.
  - *Error / Exceptional:* Non-existent agent ID reports error without state modification.

---

### 29. `main`
- **Function Number:** 29
- **Source File & Line:** [`src/main.c#L1397`](file:///c:/Users/likhi/OneDrive/Desktop/cchhss/src/main.c#L1397)
- **Purpose:** Application entry point: initializes system state (`initSystem()`), executes top-level 4-option menu loop (Customer, Agent, Manager, Exit), and on exit saves data (`saveAllData()`), deallocates memory (`freeAllMemory()`), and terminates cleanly.
- **Input Parameters:** None (`void`).
- **Return Type & Output:** `int`. Returns `0` on clean shutdown.
- **Side Effects:** Calls `initSystem()`, routes to portal menus, calls `saveAllData()` and `freeAllMemory()`.
- **Conditions & Edge Cases:**
  - *Normal:* Option 1 opens Customer Portal, Option 2 opens Agent Portal, Option 3 opens Manager Portal, Option 4 cleanly saves, frees memory, and exits with code 0.
  - *Boundary:* Immediate selection of option 4 cleanly saves and frees resources.
  - *Error / Exceptional:* Invalid top-level menu selections reprompted by `readInt()`.

---

## Verification Checklist

| Verified Item | Count / Status | Notes |
|---|---|---|
| Function Declarations in `include/complaint_system.h` | 29 | Lines 94–122 |
| Function Definitions in `src/main.c` | 29 | Lines 34–1426 |
| Function Overload / Duplicate Definitions | 0 | Pure C11 codebase; zero duplicate names |
| Helper / Fixture / Test Functions Counted | 0 | Inventory strictly limited to production code |
| Invariant Preserved | Verified | Exactly 29 distinct application functions |
