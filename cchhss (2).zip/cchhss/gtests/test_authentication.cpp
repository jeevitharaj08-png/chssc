#include "test_helpers.h"

using namespace cchhss_test;

class AuthenticationTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 4: findCustomerByUsername TESTS                                  */
/* ========================================================================= */

TEST_F(AuthenticationTest, FindCustomerByUsername_EmptyListReturnsNull) {
    EXPECT_EQ(findCustomerByUsername("alice"), nullptr);
}

TEST_F(AuthenticationTest, FindCustomerByUsername_NullOrEmptyReturnsNull) {
    EXPECT_EQ(findCustomerByUsername(NULL), nullptr);
    EXPECT_EQ(findCustomerByUsername(""), nullptr);
}

TEST_F(AuthenticationTest, FindCustomerByUsername_FindsHeadAndTailInPopulatedList) {
    std::string custData =
        "CUST1001|Alice User|alice|pass1|alice@test.com\n"
        "CUST1002|Bob User|bob|pass2|bob@test.com\n"
        "CUST1003|Charlie User|charlie|pass3|charlie@test.com\n";
    writeSandboxFile("data/customers.txt", custData);
    initSystem();

    // Verify head
    CustomerNode *c1 = findCustomerByUsername("alice");
    ASSERT_NE(c1, nullptr);
    EXPECT_STREQ(c1->data.customerId, "CUST1001");
    EXPECT_STREQ(c1->data.fullName, "Alice User");

    // Verify middle
    CustomerNode *c2 = findCustomerByUsername("bob");
    ASSERT_NE(c2, nullptr);
    EXPECT_STREQ(c2->data.customerId, "CUST1002");

    // Verify tail
    CustomerNode *c3 = findCustomerByUsername("charlie");
    ASSERT_NE(c3, nullptr);
    EXPECT_STREQ(c3->data.customerId, "CUST1003");

    // Verify nonexistent
    EXPECT_EQ(findCustomerByUsername("david"), nullptr);

    // Verify case sensitivity
    EXPECT_EQ(findCustomerByUsername("Alice"), nullptr);
}

/* ========================================================================= */
/* FUNCTION 12: customerRegister TESTS                                       */
/* ========================================================================= */

TEST_F(AuthenticationTest, CustomerRegister_RejectsBlankInputs) {
    initSystem();

    // 1. Blank full name
    {
        ScopedStdin in("\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("Registration cancelled: Full name cannot be blank."), std::string::npos);
    }

    // 2. Blank username
    {
        ScopedStdin in("Valid Name\n\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("Registration cancelled: Username cannot be blank."), std::string::npos);
    }

    // 3. Blank password
    {
        ScopedStdin in("Valid Name\nvaliduser\n\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("Registration cancelled: Password cannot be blank."), std::string::npos);
    }

    // 4. Blank contact
    {
        ScopedStdin in("Valid Name\nvaliduser\nsecretpass\n\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("Registration cancelled: Contact details cannot be blank."), std::string::npos);
    }
}

TEST_F(AuthenticationTest, CustomerRegister_RejectsDuplicateUsername) {
    initSystem();

    // Register first user
    {
        ScopedStdin in("Alice Smith\nalice\nalicepass\nalice@mail.com\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("[SUCCESS] Account created successfully!"), std::string::npos);
    }

    // Attempt registering again with same username
    {
        ScopedStdin in("Alice Duplicate\nalice\notherpass\nother@mail.com\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("already taken"), std::string::npos);
    }
}

TEST_F(AuthenticationTest, CustomerRegister_SuccessAppendsToCustomerList) {
    initSystem();

    // Register 1st customer
    {
        ScopedStdin in("Customer One\nuser1\npass1\nuser1@mail.com\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("CUST1001"), std::string::npos);
    }

    // Register 2nd customer
    {
        ScopedStdin in("Customer Two\nuser2\npass2\nuser2@mail.com\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("CUST1002"), std::string::npos);
    }

    // Register 3rd customer (exercises while loop curr = curr->next traversal)
    {
        ScopedStdin in("Customer Three\nuser3\npass3\nuser3@mail.com\n");
        ScopedStdout out;
        customerRegister();
        EXPECT_NE(out.getOutput().find("CUST1003"), std::string::npos);
    }

    CustomerNode *c1 = findCustomerByUsername("user1");
    ASSERT_NE(c1, nullptr);
    EXPECT_STREQ(c1->data.customerId, "CUST1001");

    CustomerNode *c2 = findCustomerByUsername("user2");
    ASSERT_NE(c2, nullptr);
    EXPECT_STREQ(c2->data.customerId, "CUST1002");

    CustomerNode *c3 = findCustomerByUsername("user3");
    ASSERT_NE(c3, nullptr);
    EXPECT_STREQ(c3->data.customerId, "CUST1003");
}

/* ========================================================================= */
/* FUNCTION 13: customerLogin TESTS                                          */
/* ========================================================================= */

TEST_F(AuthenticationTest, CustomerLogin_RejectsInvalidCredentials) {
    std::string custData = "CUST1001|Alice Smith|alice|pass123|contact\n";
    writeSandboxFile("data/customers.txt", custData);
    initSystem();

    // Case 1: Unknown user
    {
        ScopedStdin in("unknown\npass123\n");
        ScopedStdout out;
        customerLogin();
        EXPECT_NE(out.getOutput().find("Authentication failed: Invalid username or password."), std::string::npos);
    }

    // Case 2: Correct user, wrong password
    {
        ScopedStdin in("alice\nwrongpassword\n");
        ScopedStdout out;
        customerLogin();
        EXPECT_NE(out.getOutput().find("Authentication failed: Invalid username or password."), std::string::npos);
    }
}

TEST_F(AuthenticationTest, CustomerLogin_SuccessfulAuthenticationEntersDashboard) {
    std::string custData = "CUST1001|Alice Smith|alice|pass123|contact\n";
    writeSandboxFile("data/customers.txt", custData);
    initSystem();

    // Login with correct credentials, then select 5 to logout
    ScopedStdin in("alice\npass123\n5\n");
    ScopedStdout out;

    customerLogin();
    std::string output = out.getOutput();

    EXPECT_NE(output.find("Welcome back, Alice Smith!"), std::string::npos);
    EXPECT_NE(output.find("CUSTOMER DASHBOARD: Alice Smith (CUST1001)"), std::string::npos);
    EXPECT_NE(output.find("Logging out of customer session..."), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 14: customerDashboard TESTS                                      */
/* ========================================================================= */

TEST_F(AuthenticationTest, CustomerDashboard_NavigatesMenuOptionsAndLogsOut) {
    initSystem();

    // Sequence exercising all customerDashboard options:
    // Option 1 (Register complaint -> Cat 1, Pri 1, empty desc to abort)
    // Option 2 (View complaints)
    // Option 3 (Track complaint -> CMP999 not found)
    // Option 4 (View history -> CMP999 not found)
    // Option 5 (Logout)
    ScopedStdin in("1\n1\n1\n\n2\n3\nCMP999\n4\nCMP999\n5\n");
    ScopedStdout out;

    customerDashboard("CUST1001", "Alice Smith");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("CUSTOMER DASHBOARD: Alice Smith (CUST1001)"), std::string::npos);
    EXPECT_NE(output.find("Register a New Complaint"), std::string::npos);
    EXPECT_NE(output.find("My Registered Complaints"), std::string::npos);
    EXPECT_NE(output.find("Logging out of customer session..."), std::string::npos);
}
