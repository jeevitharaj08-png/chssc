#include "test_helpers.h"

using namespace cchhss_test;

class ManagerTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 23: managerMenu TESTS                                            */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerMenu_HandlesAuthenticationFailuresAndSuccess) {
    initSystem();

    // 1. Wrong credentials
    {
        ScopedStdin in("1\nmanager\nwrongpass\n2\n");
        ScopedStdout out;
        managerMenu();
        EXPECT_NE(out.getOutput().find("Authentication failed: Invalid manager credentials."), std::string::npos);
    }

    // 2. Correct credentials ("manager", "manager123"), enter dashboard and logout (6), then return (2)
    {
        ScopedStdin in("1\nmanager\nmanager123\n6\n2\n");
        ScopedStdout out;
        managerMenu();
        std::string output = out.getOutput();
        EXPECT_NE(output.find("Welcome, Operations Manager!"), std::string::npos);
        EXPECT_NE(output.find("MANAGER DASHBOARD"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 24: managerDashboard TESTS                                       */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerDashboard_Option5AuditHistoryEmptyAndPopulated) {
    // 1. Audit log empty
    {
        initSystem();
        ScopedStdin in("5\n6\n");
        ScopedStdout out;
        managerDashboard();
        std::string output = out.getOutput();
        EXPECT_NE(output.find("Complete System Audit History"), std::string::npos);
        EXPECT_NE(output.find("No audit events logged in system yet."), std::string::npos);
    }

    // 2. Audit log populated and testing all options of managerDashboard
    {
        std::string compData =
            "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Desc\n";
        std::string auditData =
            "CMP101|2026-10-26 10:00:00|ASSIGNED|SYSTEM|Auto-assigned to AGT101\n";
        writeSandboxFile("data/complaints.txt", compData);
        writeSandboxFile("data/audit_log.txt", auditData);
        initSystem();

        // Option 1: View all complaints
        // Option 2: Assign complaint (CMP999 abort)
        // Option 3: Update complaint (CMP999 abort)
        // Option 4: Agent management (2 return)
        // Option 5: Audit log
        // Option 6: Logout
        ScopedStdin in("1\n2\nCMP999\n3\nCMP999\n4\n2\n5\n6\n");
        ScopedStdout out;
        managerDashboard();
        std::string output = out.getOutput();
        EXPECT_NE(output.find("SYSTEM METRICS & DASHBOARD"), std::string::npos);
        EXPECT_NE(output.find("Auto-assigned to AGT101"), std::string::npos);
        EXPECT_NE(output.find("Logging out of manager session..."), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 25: managerViewAllComplaints TESTS                               */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerViewAllComplaints_ZeroAndAllStatusMetrics) {
    // 1. Zero complaints
    {
        initSystem();
        ScopedStdout out;
        managerViewAllComplaints();
        std::string output = out.getOutput();
        EXPECT_NE(output.find("Total Complaints:  0"), std::string::npos);
        EXPECT_NE(output.find("Zero complaints exist in the system."), std::string::npos);
    }

    // 2. Populated complaints in all statuses
    {
        std::string compData =
            "CMP101|CUST1001|Cat|Pri|PENDING|UNASSIGNED|T1|T2|T3|N/A|N/A|N/A|N|D\n"
            "CMP102|CUST1001|Cat|Pri|ASSIGNED|AGT101|T1|T2|T3|N/A|N/A|N/A|N|D\n"
            "CMP103|CUST1001|Cat|Pri|IN_PROGRESS|AGT101|T1|T2|T3|N/A|N/A|N/A|N|D\n"
            "CMP104|CUST1001|Cat|Pri|RESOLVED|AGT101|T1|T2|T3|T4|N/A|N/A|N|D\n"
            "CMP105|CUST1001|Cat|Pri|CLOSED|AGT101|T1|T2|T3|T4|T5|N/A|N|D\n"
            "CMP106|CUST1001|Cat|Pri|ESCALATED|AGT101|T1|T2|T3|N/A|N/A|T6|N|D\n";
        writeSandboxFile("data/complaints.txt", compData);
        initSystem();

        ScopedStdout out;
        managerViewAllComplaints();
        std::string output = out.getOutput();

        EXPECT_NE(output.find("Total Complaints:  6"), std::string::npos);
        EXPECT_NE(output.find("Pending:     1"), std::string::npos);
        EXPECT_NE(output.find("Assigned:  1"), std::string::npos);
        EXPECT_NE(output.find("In Progress:       1"), std::string::npos);
        EXPECT_NE(output.find("Escalated:   1"), std::string::npos);
        EXPECT_NE(output.find("Resolved:  1"), std::string::npos);
        EXPECT_NE(output.find("Closed:            1"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 26: managerAssignComplaint TESTS                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerAssignComplaint_NotFoundAgentNotFoundAndInactiveAbort) {
    // Make AGT102 inactive
    std::string agentsData =
        "AGT101|Agent 1|agent1|pass1|1|0\n"
        "AGT102|Agent 2|agent2|pass2|0|0\n";
    for (int i = 2; i < 10; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|agent%d|pass%d|1|0\n", 101 + i, i + 1, i + 1, i + 1);
        agentsData += buf;
    }
    std::string compData =
        "CMP101|CUST1001|Tech|High|PENDING|UNASSIGNED|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n"
        "CMP102|CUST1001|Tech|High|ASSIGNED|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/agents.txt", agentsData);
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // 1. Complaint not found
    {
        ScopedStdin in("CMP999\n");
        ScopedStdout out;
        managerAssignComplaint();
        EXPECT_NE(out.getOutput().find("Complaint ID 'CMP999' not found."), std::string::npos);
    }

    // 2. Non-existent agent ID
    {
        ScopedStdin in("CMP101\nAGT999\n");
        ScopedStdout out;
        managerAssignComplaint();
        EXPECT_NE(out.getOutput().find("Agent ID 'AGT999' does not exist."), std::string::npos);
    }

    // 3. Inactive agent ID
    {
        ScopedStdin in("CMP101\nAGT102\n");
        ScopedStdout out;
        managerAssignComplaint();
        EXPECT_NE(out.getOutput().find("Agent AGT102 is inactive. Reassignment aborted."), std::string::npos);
    }

    // 4. Valid assignment: PENDING -> ASSIGNED to AGT101
    {
        ScopedStdin in("CMP101\nAGT101\n");
        ScopedStdout out;
        managerAssignComplaint();
        EXPECT_NE(out.getOutput().find("successfully assigned to AGT101"), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "ASSIGNED");
        EXPECT_STREQ(cmp->data.assignedAgentId, "AGT101");
    }
}

/* ========================================================================= */
/* FUNCTION 27: managerUpdateComplaint TESTS                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerUpdateComplaint_AllAdministrativeActions) {
    std::string compData =
        "CMP101|CUST1001|Tech|High|PENDING|UNASSIGNED|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // 1. Not found
    {
        ScopedStdin in("CMP999\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Complaint ID 'CMP999' not found."), std::string::npos);
    }

    // 2. Cancel (Choice 5)
    {
        ScopedStdin in("CMP101\n5\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Action cancelled."), std::string::npos);
    }

    // 3. Mark IN_PROGRESS with empty note (Choice 1) -> default note
    {
        ScopedStdin in("CMP101\n1\n\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Status updated to IN_PROGRESS."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "IN_PROGRESS");
        EXPECT_STREQ(cmp->data.lastNote, "Status updated by Manager");
    }

    // 4. Mark RESOLVED with custom note (Choice 2)
    {
        ScopedStdin in("CMP101\n2\nManagement authorized full credit resolution\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Status updated to RESOLVED."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "RESOLVED");
        EXPECT_STRNE(cmp->data.timestamps.resolved, "N/A");
    }

    // 5. Mark CLOSED with custom note (Choice 3)
    {
        ScopedStdin in("CMP101\n3\nFormally closed after satisfaction verification\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Status updated to CLOSED."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "CLOSED");
        EXPECT_STRNE(cmp->data.timestamps.closed, "N/A");
    }

    // 6. Mark ESCALATED with custom note (Choice 4)
    {
        ScopedStdin in("CMP101\n4\nEscalated to VP of Operations\n");
        ScopedStdout out;
        managerUpdateComplaint();
        EXPECT_NE(out.getOutput().find("Complaint ESCALATED."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "ESCALATED");
        EXPECT_STRNE(cmp->data.timestamps.escalated, "N/A");
    }
}

/* ========================================================================= */
/* FUNCTION 28: managerAgentManagement TESTS                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerAgentManagement_TogglesStatusAndHandlesErrors) {
    std::string compData =
        "CMP102|CUST1001|Tech|High|ASSIGNED|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // Choice 1 -> toggle AGT999 (not found)
    // Choice 1 -> toggle AGT101 (becomes INACTIVE)
    // Choice 1 -> toggle AGT101 (becomes ACTIVE again)
    // Choice 2 -> return to manager menu
    ScopedStdin in("1\nAGT999\n1\nAGT101\n1\nAGT101\n2\n");
    ScopedStdout out;

    managerAgentManagement();
    std::string output = out.getOutput();

    EXPECT_NE(output.find("SUPPORT AGENT MANAGEMENT"), std::string::npos);
    EXPECT_NE(output.find("Error: Agent ID 'AGT999' not found."), std::string::npos);
    EXPECT_NE(output.find("Agent AGT101 status toggled to INACTIVE."), std::string::npos);
    EXPECT_NE(output.find("Agent AGT101 status toggled to ACTIVE."), std::string::npos);
}
