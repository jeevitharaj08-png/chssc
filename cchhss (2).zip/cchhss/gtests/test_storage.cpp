#include "test_helpers.h"

using namespace cchhss_test;

class StorageTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 8: initSystem TESTS                                              */
/* ========================================================================= */

TEST_F(StorageTest, InitSystem_FreshStateWithoutDataFiles) {
    cleanSandboxData();

    initSystem();

    // Check that default agents were initialized and counters start at 101 / 1001
    // We can verify this by checking that autoAssignAgent finds an active agent
    EXPECT_GE(autoAssignAgent(), 0);

    // Verify customerHead and complaintHead are empty
    EXPECT_EQ(findCustomerByUsername("anyuser"), nullptr);
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

TEST_F(StorageTest, InitSystem_LoadsPartialAgentsFileAndFillsDefaults) {
    // Write only 2 agents in agents.txt
    std::string partialAgents =
        "AGT101|Custom Agent 1|cagent1|pass1|1|5\n"
        "AGT102|Custom Agent 2|cagent2|pass2|0|2\n";
    writeSandboxFile("data/agents.txt", partialAgents);

    initSystem();

    // The remaining 8 agents should be populated with defaults
    // Let's verify by saving and inspecting the saved agent count (must have 10 lines)
    saveAllData();
    std::string savedAgents = readSandboxFile("data/agents.txt");
    int lineCount = 0;
    std::istringstream iss(savedAgents);
    std::string line;
    while (std::getline(iss, line)) {
        if (!line.empty()) lineCount++;
    }
    EXPECT_EQ(lineCount, 10);
    EXPECT_NE(savedAgents.find("Custom Agent 1"), std::string::npos);
    EXPECT_NE(savedAgents.find("Julia Roberts"), std::string::npos);
}

TEST_F(StorageTest, InitSystem_LoadsCountersWithClampingAndCorruptionHandling) {
    // Case 1: Corrupted counters file
    writeSandboxFile("data/counters.txt", "invalid_data\n");
    initSystem();

    // Case 2: Counters below minimum bounds (50, 500) clamped to 101 and 1001
    writeSandboxFile("data/counters.txt", "50\n500\n");
    initSystem();

    // Case 3: Counters above minimum bounds
    writeSandboxFile("data/counters.txt", "250\n2050\n");
    initSystem();

    saveAllData();
    std::string savedCounters = readSandboxFile("data/counters.txt");
    EXPECT_NE(savedCounters.find("250"), std::string::npos);
    EXPECT_NE(savedCounters.find("2050"), std::string::npos);
}

TEST_F(StorageTest, InitSystem_LoadsCustomersComplaintsAndAudits) {
    std::string custData =
        "CUST1001|Alice Smith|alice|pass1|alice@example.com\n"
        "CUST1002|Bob Jones|bob|pass2|bob@example.com\n";
    writeSandboxFile("data/customers.txt", custData);

    std::string compData =
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|2026-10-26 10:05:00|2026-10-26 10:05:00|N/A|N/A|N/A|Initial|Network Down\n"
        "CMP102|CUST1002|Billing and Account|Low|PENDING|UNASSIGNED|2026-10-26 11:00:00|N/A|2026-10-26 11:00:00|N/A|N/A|N/A|Check|Overcharge\n";
    writeSandboxFile("data/complaints.txt", compData);

    // Audit logs: one with details (p==5), one with 4 tokens (p==4, empty details),
    // a 3rd entry to exercise while loop curA = curA->next traversal,
    // and one for a non-existent complaint to test orphan skip
    std::string auditData =
        "CMP101|2026-10-26 10:00:00|REGISTERED|CUST1001|Registered by customer\n"
        "CMP101|2026-10-26 10:05:00|ASSIGNED|SYSTEM|\n" // 4 tokens / blank details
        "CMP101|2026-10-26 10:10:00|IN_PROGRESS|AGT101|Investigating issue\n" // 3rd entry
        "CMP999|2026-10-26 10:06:00|ACTION|UNKNOWN|Orphan audit\n";
    writeSandboxFile("data/audit_log.txt", auditData);

    initSystem();

    // Verify customers loaded
    CustomerNode *c1 = findCustomerByUsername("alice");
    ASSERT_NE(c1, nullptr);
    EXPECT_STREQ(c1->data.customerId, "CUST1001");
    EXPECT_STREQ(c1->data.contact, "alice@example.com");

    CustomerNode *c2 = findCustomerByUsername("bob");
    ASSERT_NE(c2, nullptr);
    EXPECT_STREQ(c2->data.customerId, "CUST1002");

    // Verify complaints loaded
    ComplaintNode *cmp1 = findComplaintById("CMP101");
    ASSERT_NE(cmp1, nullptr);
    EXPECT_STREQ(cmp1->data.status, "ASSIGNED");

    // Verify audits loaded into CMP101
    ASSERT_NE(cmp1->auditHead, nullptr);
    EXPECT_STREQ(cmp1->auditHead->action, "REGISTERED");
    ASSERT_NE(cmp1->auditHead->next, nullptr);
    EXPECT_STREQ(cmp1->auditHead->next->action, "ASSIGNED");
    EXPECT_STREQ(cmp1->auditHead->next->details, "");
}

/* ========================================================================= */
/* FUNCTION 9: saveAllData TESTS                                             */
/* ========================================================================= */

TEST_F(StorageTest, SaveAllData_EmptyStateCreatesValidFiles) {
    cleanSandboxData();
    initSystem();

    saveAllData();

    EXPECT_TRUE(std::ifstream("data/counters.txt").good());
    EXPECT_TRUE(std::ifstream("data/agents.txt").good());
    EXPECT_TRUE(std::ifstream("data/customers.txt").good());
    EXPECT_TRUE(std::ifstream("data/complaints.txt").good());
    EXPECT_TRUE(std::ifstream("data/audit_log.txt").good());
}

TEST_F(StorageTest, SaveAllData_PersistsFallbackValuesForEmptyFields) {
    // Write valid complaint record
    std::string compData =
        "CMP101|CUST1001|Other|Low|PENDING|UNASSIGNED|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Description text\n";
    writeSandboxFile("data/complaints.txt", compData);

    initSystem();

    // In memory, clear the optional timestamps and lastNote to exercise ternary fallbacks
    ComplaintNode *cmp = findComplaintById("CMP101");
    ASSERT_NE(cmp, nullptr);
    cmp->data.timestamps.registered[0] = '\0';
    cmp->data.timestamps.assigned[0] = '\0';
    cmp->data.timestamps.updated[0] = '\0';
    cmp->data.timestamps.resolved[0] = '\0';
    cmp->data.timestamps.closed[0] = '\0';
    cmp->data.timestamps.escalated[0] = '\0';
    cmp->data.lastNote[0] = '\0';

    saveAllData();

    std::string saved = readSandboxFile("data/complaints.txt");
    EXPECT_NE(saved.find("CMP101"), std::string::npos);
    EXPECT_NE(saved.find("N/A"), std::string::npos); // Empty timestamps replaced by "N/A"
    EXPECT_NE(saved.find("No notes yet"), std::string::npos); // Empty note replaced
}

/* ========================================================================= */
/* FUNCTION 10: freeAllMemory TESTS                                          */
/* ========================================================================= */

TEST_F(StorageTest, FreeAllMemory_EmptyAndRepeatedCallsSafe) {
    // Should safely do nothing when already empty
    freeAllMemory();
    freeAllMemory();
    SUCCEED();
}

TEST_F(StorageTest, FreeAllMemory_FreesPopulatedStructuresCleanly) {
    std::string custData = "CUST1001|Alice|alice|pass|contact\n";
    writeSandboxFile("data/customers.txt", custData);
    std::string compData = "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    std::string auditData = "CMP101|2026-10-26 10:00:00|REGISTERED|CUST1001|Details\n";
    writeSandboxFile("data/audit_log.txt", auditData);

    initSystem();
    ASSERT_NE(findCustomerByUsername("alice"), nullptr);
    ASSERT_NE(findComplaintById("CMP101"), nullptr);

    freeAllMemory();

    // Verify lists are cleared
    EXPECT_EQ(findCustomerByUsername("alice"), nullptr);
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);

    // Call again to verify idempotence
    freeAllMemory();
    SUCCEED();
}
