#ifndef TEST_HELPERS_H
#define TEST_HELPERS_H

#include <gtest/gtest.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <io.h>
#include <fcntl.h>
#include <direct.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <windows.h>
#endif

extern "C" {
#define main app_main
#include "../include/complaint_system.h"
#undef main

/* When compiled with -Dmain=app_main, main() in src/main.c is exposed as app_main() */
int app_main(void);
}

namespace cchhss_test {

/* Helper to manage isolated input redirection to stdin */
class ScopedStdin {
public:
    explicit ScopedStdin(const std::string &inputContent) {
        static int counter = 0;
        char tempPath[MAX_PATH];
        snprintf(tempPath, sizeof(tempPath), "test_stdin_temp_%d_%ld.txt", ++counter, (long)GetCurrentProcessId());
        m_filename = tempPath;

        // Write simulated input to temp file
        FILE *f = fopen(m_filename.c_str(), "wb");
        if (f) {
            fwrite(inputContent.data(), 1, inputContent.size(), f);
            fclose(f);
        }

        // Flush and clear existing stdin stream state
        fflush(stdin);
        clearerr(stdin);
        m_savedStdin = _dup(_fileno(stdin));

        // Redirect stdin to temp file
        m_file = fopen(m_filename.c_str(), "rb");
        if (m_file) {
            _dup2(_fileno(m_file), _fileno(stdin));
            rewind(stdin);
            clearerr(stdin);
        }
    }

    ~ScopedStdin() {
        if (m_file) {
            fclose(m_file);
            m_file = nullptr;
        }
        if (m_savedStdin != -1) {
            _dup2(m_savedStdin, _fileno(stdin));
            rewind(stdin);
            clearerr(stdin);
            _close(m_savedStdin);
            m_savedStdin = -1;
        }
        if (!m_filename.empty()) {
            remove(m_filename.c_str());
        }
    }

private:
    std::string m_filename;
    FILE *m_file = nullptr;
    int m_savedStdin = -1;
};

/* Helper to capture stdout */
class ScopedStdout {
public:
    ScopedStdout() {
        static int counter = 0;
        char tempPath[MAX_PATH];
        snprintf(tempPath, sizeof(tempPath), "test_stdout_temp_%d_%ld.txt", ++counter, (long)GetCurrentProcessId());
        m_filename = tempPath;

        fflush(stdout);
        m_savedStdout = _dup(_fileno(stdout));

        m_file = fopen(m_filename.c_str(), "wb");
        if (m_file) {
            _dup2(_fileno(m_file), _fileno(stdout));
        }
    }

    std::string getOutput() {
        restore();
        std::ifstream ifs(m_filename, std::ios::binary);
        if (!ifs) return "";
        std::ostringstream oss;
        oss << ifs.rdbuf();
        return oss.str();
    }

    ~ScopedStdout() {
        restore();
        if (!m_filename.empty()) {
            remove(m_filename.c_str());
        }
    }

private:
    void restore() {
        if (m_restored) return;
        m_restored = true;
        fflush(stdout);
        if (m_file) {
            fclose(m_file);
            m_file = nullptr;
        }
        if (m_savedStdout != -1) {
            _dup2(m_savedStdout, _fileno(stdout));
            _close(m_savedStdout);
            m_savedStdout = -1;
        }
    }

    std::string m_filename;
    FILE *m_file = nullptr;
    int m_savedStdout = -1;
    bool m_restored = false;
};

/* Base test fixture ensuring sandbox isolation and clean state between tests */
class ComplaintSystemTest : public ::testing::Test {
protected:
    static std::string s_originalCwd;
    static std::string s_sandboxPath;

    static void SetUpTestSuite() {
        char buf[MAX_PATH];
        if (_getcwd(buf, sizeof(buf))) {
            s_originalCwd = buf;
        }
        s_sandboxPath = s_originalCwd + "\\gtests\\sandbox";
        _mkdir(s_sandboxPath.c_str());
    }

    static void TearDownTestSuite() {
        if (!s_originalCwd.empty()) {
            _chdir(s_originalCwd.c_str());
        }
    }

    void SetUp() override {
        // Change working directory to sandbox for complete file isolation
        _chdir(s_sandboxPath.c_str());

        // Always clean any existing in-memory structures
        freeAllMemory();

        // Ensure sandbox data folder exists and is cleaned
        _mkdir("data");
        cleanSandboxData();
    }

    void TearDown() override {
        // Free all heap nodes created during the test
        freeAllMemory();

        // Clean sandbox data directory
        cleanSandboxData();

        // Restore working directory
        _chdir(s_sandboxPath.c_str());
    }

    void cleanSandboxData() {
        remove("data/counters.txt");
        remove("data/agents.txt");
        remove("data/customers.txt");
        remove("data/complaints.txt");
        remove("data/audit_log.txt");
    }

    void writeSandboxFile(const std::string &relPath, const std::string &content) {
        FILE *f = fopen(relPath.c_str(), "w");
        if (f) {
            fputs(content.c_str(), f);
            fclose(f);
        }
    }

    std::string readSandboxFile(const std::string &relPath) {
        std::ifstream ifs(relPath, std::ios::binary);
        if (!ifs) return "";
        std::ostringstream oss;
        oss << ifs.rdbuf();
        return oss.str();
    }
};

inline std::string ComplaintSystemTest::s_originalCwd;
inline std::string ComplaintSystemTest::s_sandboxPath;

} // namespace cchhss_test

#endif // TEST_HELPERS_H
