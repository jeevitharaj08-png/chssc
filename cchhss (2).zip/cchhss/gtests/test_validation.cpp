#include "test_helpers.h"

using namespace cchhss_test;

class ValidationTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 1: getTimestamp TESTS                                            */
/* ========================================================================= */

TEST_F(ValidationTest, GetTimestamp_NormalValidBuffer) {
    char buffer[64] = {0};
    getTimestamp(buffer, sizeof(buffer));

    // Verify format: YYYY-MM-DD HH:MM:SS (length exactly 19)
    ASSERT_EQ(strlen(buffer), 19u);
    EXPECT_TRUE(isdigit(buffer[0]));
    EXPECT_TRUE(isdigit(buffer[1]));
    EXPECT_TRUE(isdigit(buffer[2]));
    EXPECT_TRUE(isdigit(buffer[3]));
    EXPECT_EQ(buffer[4], '-');
    EXPECT_TRUE(isdigit(buffer[5]));
    EXPECT_TRUE(isdigit(buffer[6]));
    EXPECT_EQ(buffer[7], '-');
    EXPECT_TRUE(isdigit(buffer[8]));
    EXPECT_TRUE(isdigit(buffer[9]));
    EXPECT_EQ(buffer[10], ' ');
    EXPECT_TRUE(isdigit(buffer[11]));
    EXPECT_TRUE(isdigit(buffer[12]));
    EXPECT_EQ(buffer[13], ':');
    EXPECT_TRUE(isdigit(buffer[14]));
    EXPECT_TRUE(isdigit(buffer[15]));
    EXPECT_EQ(buffer[16], ':');
    EXPECT_TRUE(isdigit(buffer[17]));
    EXPECT_TRUE(isdigit(buffer[18]));
}

TEST_F(ValidationTest, GetTimestamp_NullBufferHandledSafely) {
    // Should return immediately without dereferencing NULL
    getTimestamp(NULL, 64);
    SUCCEED();
}

TEST_F(ValidationTest, GetTimestamp_ZeroSizeHandledSafely) {
    char buffer[32] = "SENTINEL";
    getTimestamp(buffer, 0);
    // Buffer must remain untouched
    EXPECT_STREQ(buffer, "SENTINEL");
}

TEST_F(ValidationTest, GetTimestamp_ExactBoundarySize20) {
    char buffer[20] = {0};
    getTimestamp(buffer, sizeof(buffer));
    EXPECT_EQ(strlen(buffer), 19u);
    EXPECT_EQ(buffer[19], '\0');
}

/* ========================================================================= */
/* FUNCTION 2: readString TESTS                                              */
/* ========================================================================= */

TEST_F(ValidationTest, ReadString_NormalInputWithNewlineStripping) {
    ScopedStdin in("Normal input line\n");
    char buffer[64] = {0};

    readString("Prompt: ", buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "Normal input line");
}

TEST_F(ValidationTest, ReadString_StripsCarriageReturnAndNewline) {
    ScopedStdin in("Windows Line\r\n");
    char buffer[64] = {0};

    readString("", buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "Windows Line");
}

TEST_F(ValidationTest, ReadString_StripsMultipleTrailingNewlines) {
    ScopedStdin in("MultiNewline\r\r\n");
    char buffer[64] = {0};

    readString(NULL, buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "MultiNewline");
}

TEST_F(ValidationTest, ReadString_ReplacesPipesWithHyphens) {
    ScopedStdin in("alpha|beta|gamma|delta\n");
    char buffer[64] = {0};

    readString(NULL, buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "alpha-beta-gamma-delta");
}

TEST_F(ValidationTest, ReadString_HandlesNullBufferAndZeroSize) {
    ScopedStdin in("Some line\n");

    readString("Test prompt", NULL, 64);
    char buf[16] = "Test";
    readString("Test prompt", buf, 0);
    EXPECT_STREQ(buf, "Test");
}

TEST_F(ValidationTest, ReadString_HandlesEofOnStdin) {
    ScopedStdin in(""); // Empty input simulates immediate EOF
    char buffer[32] = "Initial";

    readString(NULL, buffer, sizeof(buffer));
    EXPECT_EQ(buffer[0], '\0');
}

TEST_F(ValidationTest, ReadString_DisplaysPromptWhenProvided) {
    ScopedStdin in("John Doe\n");
    ScopedStdout out;
    char buffer[64] = {0};

    readString("Enter Name: ", buffer, sizeof(buffer));
    std::string captured = out.getOutput();

    EXPECT_STREQ(buffer, "John Doe");
    EXPECT_NE(captured.find("Enter Name: "), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 3: readInt TESTS                                                 */
/* ========================================================================= */

TEST_F(ValidationTest, ReadInt_ValidWithinRange) {
    ScopedStdin in("4\n");
    ScopedStdout out;

    int val = readInt("Select option: ", 1, 5);
    EXPECT_EQ(val, 4);
}

TEST_F(ValidationTest, ReadInt_LowerAndUpperBoundaryValues) {
    {
        ScopedStdin in("1\n");
        ScopedStdout out;
        int val = readInt(NULL, 1, 10);
        EXPECT_EQ(val, 1);
    }
    {
        ScopedStdin in("10\n");
        ScopedStdout out;
        int val = readInt(NULL, 1, 10);
        EXPECT_EQ(val, 10);
    }
}

TEST_F(ValidationTest, ReadInt_RepromptOnOutOfRangeLowThenHighThenValid) {
    ScopedStdin in("0\n15\n3\n");
    ScopedStdout out;

    int val = readInt("Enter: ", 1, 10);
    std::string output = out.getOutput();

    EXPECT_EQ(val, 3);
    EXPECT_NE(output.find("Invalid choice. Please enter a number between 1 and 10: "), std::string::npos);
}

TEST_F(ValidationTest, ReadInt_RepromptOnNonNumericAndPartiallyNumericInput) {
    ScopedStdin in("invalid\n12junk\n7\n");
    ScopedStdout out;

    int val = readInt("Enter: ", 1, 10);
    std::string output = out.getOutput();

    EXPECT_EQ(val, 7);
    EXPECT_NE(output.find("Invalid choice. Please enter a number between 1 and 10: "), std::string::npos);
}

TEST_F(ValidationTest, ReadInt_RepromptOnEmptyLineInput) {
    ScopedStdin in("\n5\n");
    ScopedStdout out;

    int val = readInt("Enter: ", 1, 10);
    std::string output = out.getOutput();

    EXPECT_EQ(val, 5);
    EXPECT_NE(output.find("Input cannot be empty. Please enter a number between 1 and 10: "), std::string::npos);
}

TEST_F(ValidationTest, ReadInt_ReturnsMinValOnEofToPreventInfiniteLoop) {
    ScopedStdin in(""); // Empty input immediately triggers EOF
    ScopedStdout out;

    int val = readInt("Enter: ", 5, 20);
    EXPECT_EQ(val, 5); // Must safely return minVal
}
