@echo off
setlocal
cd /d "%~dp0\.."
echo ========================================================
echo Compiling and Running Google Test Suite (66 Test Cases)
echo ========================================================

if exist gtests\*.gcda del /Q gtests\*.gcda
if exist gtests\*.gcno del /Q gtests\*.gcno
if exist gtests\*.o del /Q gtests\*.o

C:\msys64\ucrt64\bin\gcc.exe -std=c11 --coverage -Wall -Wextra -Iinclude -Dmain=app_main -c src\main.c -o gtests\main_app.o
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to compile src/main.c
    exit /b %ERRORLEVEL%
)

C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_main.cpp -o gtests\test_main.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_validation.cpp -o gtests\test_validation.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_complaints.cpp -o gtests\test_complaints.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_storage.cpp -o gtests\test_storage.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_authentication.cpp -o gtests\test_authentication.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_customer.cpp -o gtests\test_customer.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_agent.cpp -o gtests\test_agent.o
C:\msys64\ucrt64\bin\g++.exe -std=c++17 --coverage -Iinclude -Igtests -c gtests\test_manager.cpp -o gtests\test_manager.o

C:\msys64\ucrt64\bin\g++.exe --coverage -o gtests\complaint_tests.exe gtests\test_main.o gtests\test_validation.o gtests\test_complaints.o gtests\test_storage.o gtests\test_authentication.o gtests\test_customer.o gtests\test_agent.o gtests\test_manager.o gtests\main_app.o -L C:\msys64\ucrt64\lib -lgtest
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to link complaint_tests.exe
    exit /b %ERRORLEVEL%
)

echo [SUCCESS] Executable built: gtests\complaint_tests.exe
echo Running tests...
gtests\complaint_tests.exe

echo.
echo Generating Code Coverage Reports...
C:\msys64\ucrt64\bin\gcovr.exe --filter "src/" --html-details -o gtests\coverage\coverage.html
C:\msys64\ucrt64\bin\gcovr.exe --filter "src/" --print-summary --txt gtests\coverage\coverage_summary.txt
echo [DONE] HTML report generated at gtests\coverage\coverage.html
