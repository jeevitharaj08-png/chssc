# Complaint Handling System - Traceability Matrix & Test Case Catalog

This document provides complete end-to-end requirement-to-test traceability for all **29 application functions** of the Complaint Handling System.

All 66 executable Google Test test cases map directly to their corresponding function specifications, covering normal operations, boundary limits, invalid inputs, security violations, file storage, and loop iterations.

---

## Traceability Table

| Function | Test Case ID | Scenario | Input / Preconditions | Expected Result | Test Status |
|---|---|---|---|---|---|
| **1. getTimestamp** | `TC-VAL-01` | Normal timestamp generation | Buffer size 64, system time valid | Formats string in `YYYY-MM-DD HH:MM:SS` format (19 chars) | **PASSED** |
| **1. getTimestamp** | `TC-VAL-02` | Null destination pointer | `buffer == NULL`, size 64 | Returns safely without null pointer dereference | **PASSED** |
| **1. getTimestamp** | `TC-VAL-03` | Zero buffer size boundary | Non-null buffer, `size == 0` | Returns immediately; buffer remains unchanged | **PASSED** |
| **1. getTimestamp** | `TC-VAL-04` | Exact boundary buffer capacity | Buffer size 20 (19 chars + null terminator) | Exact fit without truncation or buffer overflow | **PASSED** |
| **2. readString** | `TC-VAL-05` | Normal string input with newline | Input: `"Normal input line\n"`, prompt provided | Reads string, strips trailing newline, prints prompt | **PASSED** |
| **2. readString** | `TC-VAL-06` | CRLF newline stripping | Input: `"Windows Line\r\n"` | Strips both `\r` and `\n`, returning `"Windows Line"` | **PASSED** |
| **2. readString** | `TC-VAL-07` | Multiple trailing carriage returns | Input: `"MultiNewline\r\r\n"` | Strips all trailing `\r` and `\n` characters | **PASSED** |
| **2. readString** | `TC-VAL-08` | Delimiter sanitation | Input: `"alpha\|beta\|gamma\|delta\n"` | Replaces `\|` characters with `-` to preserve file integrity | **PASSED** |
| **2. readString** | `TC-VAL-09` | Null buffer or zero size | `buffer == NULL` or `size == 0` | Returns safely without memory violation | **PASSED** |
| **2. readString** | `TC-VAL-10` | Immediate EOF on stdin | Empty input stream (EOF) | Sets `buffer[0] = '\0'` without crashing | **PASSED** |
| **2. readString** | `TC-VAL-11` | Custom prompt display | Prompt: `"Enter Name: "` | Successfully flushes prompt string to stdout | **PASSED** |
| **3. readInt** | `TC-VAL-12` | Normal integer within range | Input: `"4\n"`, range [1, 5] | Parses and returns integer 4 | **PASSED** |
| **3. readInt** | `TC-VAL-13` | Boundary values (minVal, maxVal) | Input: `"1\n"`, `"10\n"` for range [1, 10] | Returns exact boundary values 1 and 10 | **PASSED** |
| **3. readInt** | `TC-VAL-14` | Out of range reprompt | Input: `"0\n"`, `"15\n"`, `"3\n"` for [1, 10] | Reprompts twice with error, then returns 3 | **PASSED** |
| **3. readInt** | `TC-VAL-15` | Non-numeric and partial string | Input: `"invalid\n"`, `"12junk\n"`, `"7\n"` | Reprompts twice, then parses and returns 7 | **PASSED** |
| **3. readInt** | `TC-VAL-16` | Empty line input reprompt | Input: `"\n"`, `"5\n"` | Reprompts with empty line notice, returns 5 | **PASSED** |
| **3. readInt** | `TC-VAL-17` | EOF recovery | Immediate EOF on stdin | Returns `minVal` to break infinite interactive loop | **PASSED** |
| **4. findCustomerByUsername** | `TC-AUTH-01` | Lookup in empty list | `customerHead == NULL`, query: `"alice"` | Returns `NULL` | **PASSED** |
| **4. findCustomerByUsername** | `TC-AUTH-02` | Null or empty username | `username == NULL` or `""` | Returns `NULL` without list traversal | **PASSED** |
| **4. findCustomerByUsername** | `TC-AUTH-03` | Multi-node traversal & case sensitivity | Populated list (`alice`, `bob`, `charlie`) | Finds head (`alice`), middle (`bob`), tail (`charlie`); rejects `"Alice"` and `"david"` | **PASSED** |
| **5. findComplaintById** | `TC-CMP-01` | Lookup in empty complaint list | `complaintHead == NULL`, query: `"CMP101"` | Returns `NULL` | **PASSED** |
| **5. findComplaintById** | `TC-CMP-02` | Null or empty complaint ID | `complaintId == NULL` or `""` | Returns `NULL` | **PASSED** |
| **5. findComplaintById** | `TC-CMP-03` | Head, middle, tail and case check | Populated list (`CMP101`, `CMP102`, `CMP103`) | Finds head, middle, tail; rejects `"CMP999"` and `"cmp101"` | **PASSED** |
| **6. addAuditEntry** | `TC-CMP-04` | Null complaint node | `node == NULL` | Early return without crash or allocation | **PASSED** |
| **6. addAuditEntry** | `TC-CMP-05` | First entry on empty audit trail | Complaint node with `auditHead == NULL` | Allocates new node; sets `auditHead`; captures timestamp | **PASSED** |
| **6. addAuditEntry** | `TC-CMP-06` | Chronological multi-node append | Append 3 entries sequentially | Preserves strict chronological singly linked list order | **PASSED** |
| **6. addAuditEntry** | `TC-CMP-07` | Null string parameters fallback | `action == NULL`, `by == NULL`, `details == NULL` | Defaults to `"ACTION"`, `"SYSTEM"`, and `""` | **PASSED** |
| **7. autoAssignAgent** | `TC-AGT-01` | All support agents inactive | All 10 agents marked `isActive == 0` | Returns `-1` | **PASSED** |
| **7. autoAssignAgent** | `TC-AGT-02` | Optimal workload selection | Agents with varying active and resolved tickets | Excludes RESOLVED/CLOSED; picks agent with min workload (AGT103) | **PASSED** |
| **8. initSystem** | `TC-STOR-01` | Clean boot without data files | Missing `data/` files | Creates defaults: 10 agents, counters 101/1001, empty lists | **PASSED** |
| **8. initSystem** | `TC-STOR-02` | Partial agents file handling | `agents.txt` containing only 2 agents | Loads 2 custom agents; populates remaining 8 from defaults | **PASSED** |
| **8. initSystem** | `TC-STOR-03` | Corrupt & out-of-bounds counters | Corrupt text and values below 101/1001 | Clamps counters to valid minimums (>= 101, >= 1001) | **PASSED** |
| **8. initSystem** | `TC-STOR-04` | Entity and audit trail restoration | Populated `customers.txt`, `complaints.txt`, `audit_log.txt` | Restores all nodes, links audit chains, skips orphan logs | **PASSED** |
| **9. saveAllData** | `TC-STOR-05` | Save on clean / empty system | Zero customers, zero complaints | Writes valid header/structure to all 5 text database files | **PASSED** |
| **9. saveAllData** | `TC-STOR-06` | Persist fallback values | Empty timestamp and blank note fields | Emits fallback `"N/A"` and `"No notes yet"` delimiters | **PASSED** |
| **10. freeAllMemory** | `TC-STOR-07` | Deallocation on empty system | Called when lists are empty; repeated calls | Safely no-ops; fully idempotent | **PASSED** |
| **10. freeAllMemory** | `TC-STOR-08` | Full heap deallocation | Populated customers, complaints, and audit chains | Frees every node; resets `customerHead` and `complaintHead` to NULL | **PASSED** |
| **11. customerMenu** | `TC-CUST-01` | Customer portal routing | Choices: 1 (Register), 2 (Login), 3 (Return) | Routes to register and login subroutines, then returns | **PASSED** |
| **12. customerRegister** | `TC-AUTH-04` | Input validation rejection | Blank name, blank username, blank password, blank contact | Rejects each invalid submission with dedicated error message | **PASSED** |
| **12. customerRegister** | `TC-AUTH-05` | Unique username constraint | Duplicate username already in system | Blocks registration with username already taken notice | **PASSED** |
| **12. customerRegister** | `TC-AUTH-06` | Successful multi-user registration | Register 3 unique customers sequentially | Issues `CUST1001`, `CUST1002`, `CUST1003`; verifies list append traversal | **PASSED** |
| **13. customerLogin** | `TC-AUTH-07` | Authentication rejection | Non-existent username; valid username with wrong password | Denies access with authentication failure notice | **PASSED** |
| **13. customerLogin** | `TC-AUTH-08` | Successful login | Valid username and password | Displays welcome message and launches customer dashboard | **PASSED** |
| **14. customerDashboard** | `TC-AUTH-09` | Customer session navigation | Execute options 1, 2, 3, 4, then option 5 (Logout) | Successfully invokes all customer portal features and logs out | **PASSED** |
| **15. customerRegisterComplaint** | `TC-CUST-02` | Abort on blank description | Category 1, Priority 2, empty description line | Aborts complaint creation; no ticket allocated | **PASSED** |
| **15. customerRegisterComplaint** | `TC-CUST-03` | Normal registration with auto-assign | Valid category, priority, and description | Issues `CMP101`, assigns least-loaded agent, logs audit | **PASSED** |
| **15. customerRegisterComplaint** | `TC-CUST-04` | Auto-assignment fallback | No active agents in system | Sets status to `PENDING`, agent to `UNASSIGNED`, timestamp `N/A` | **PASSED** |
| **15. customerRegisterComplaint** | `TC-CUST-05` | Collision avoidance & append traversal | In-memory ID collision, multiple complaints | Skips colliding ID, claims next free ID, appends to tail | **PASSED** |
| **16. customerViewComplaints** | `TC-CUST-06` | Zero complaints display | Customer account with no tickets | Prints `"No complaints found under your account."` | **PASSED** |
| **16. customerViewComplaints** | `TC-CUST-07` | Multi-complaint isolation | System with tickets belonging to multiple users | Displays only owned tickets; strictly excludes other customers' data | **PASSED** |
| **17. customerTrackComplaint** | `TC-CUST-08` | Non-existent ticket & authorization | Missing ID (`CMP999`); ticket owned by different user | Rejects not found; blocks cross-customer tracking | **PASSED** |
| **17. customerTrackComplaint** | `TC-CUST-09` | Lifecycle stage verification | Complaints in PENDING, ASSIGNED, IN_PROGRESS, ESCALATED, RESOLVED, CLOSED, CUSTOM | Verifies stage descriptions across all status branches | **PASSED** |
| **18. customerViewHistory** | `TC-CUST-10` | Audit trail security & display | Missing ID, unauthorized access, 0 audits, populated audits | Rejects unauthorized queries; displays audit history table | **PASSED** |
| **19. agentMenu** | `TC-AGT-03` | Authentication and availability | Invalid credentials; inactive agent account; active agent | Rejects bad logins; blocks inactive agents; opens dashboard on success | **PASSED** |
| **20. agentDashboard** | `TC-AGT-04` | Agent dashboard navigation | Options 1 (Assigned), 2 (Update), 3 (History), 4 (Logout) | Calculates workload; displays audits; logs out cleanly | **PASSED** |
| **21. agentViewAssigned** | `TC-AGT-05` | Assigned ticket list display | 0 assigned tickets vs 1 or more assigned tickets | Displays empty notice or formatted table of assigned tickets | **PASSED** |
| **22. agentUpdateComplaint** | `TC-AGT-06` | Missing and unauthorized ticket | Non-existent ID; ticket assigned to another agent | Rejects missing ID; prohibits updating other agents' tickets | **PASSED** |
| **22. agentUpdateComplaint** | `TC-AGT-07` | Status transitions and notes | Cancel (4), IN_PROGRESS (1), ESCALATED (3), RESOLVED (2) | Updates status, timestamps, notes; increments resolved count | **PASSED** |
| **23. managerMenu** | `TC-MGR-01` | Manager portal authentication | Wrong password; valid credentials (`manager` / `manager123`) | Rejects invalid credentials; grants manager dashboard access | **PASSED** |
| **24. managerDashboard** | `TC-MGR-02` | Manager navigation & system audit | Options 1, 2, 3, 4, 5 (empty & populated audit log), 6 (Logout) | Accesses all administrative functions; logs out cleanly | **PASSED** |
| **25. managerViewAllComplaints** | `TC-MGR-03` | System metrics dashboard | 0 complaints vs complaints across all 6 status categories | Tallies metrics across PENDING, ASSIGNED, IN_PROGRESS, ESCALATED, RESOLVED, CLOSED | **PASSED** |
| **26. managerAssignComplaint** | `TC-MGR-04` | Reassignment validation & execution | Non-existent ticket; invalid agent; inactive agent; active agent | Rejects invalid requests; reassigns ticket; updates status to ASSIGNED | **PASSED** |
| **27. managerUpdateComplaint** | `TC-MGR-05` | Administrative status update | Cancel (5), IN_PROGRESS (1), RESOLVED (2), CLOSED (3), ESCALATED (4) | Updates status and corresponding timestamps; appends audit record | **PASSED** |
| **28. managerAgentManagement** | `TC-MGR-06` | Agent availability toggle | Non-existent agent ID; toggle AGT101 ACTIVE <-> INACTIVE | Displays agent metrics table; toggles availability; persists change | **PASSED** |
| **29. main** | `TC-MAIN-01` | Immediate clean shutdown | Choice 4 (Exit) | Initializes system, saves state, releases memory, returns 0 | **PASSED** |
| **29. main** | `TC-MAIN-02` | Portal traversal loop | Choice 1 (Customer), 2 (Agent), 3 (Manager), 4 (Exit) | Traverses all three sub-portals and terminates cleanly with code 0 | **PASSED** |

---

## Test Execution Summary

- **Total Application Functions Under Test:** 29 of 29 (100% Function Coverage)
- **Total Google Test Cases Executed:** 66
- **Total Passed:** 66
- **Total Failed:** 0
- **Line Coverage Verified:** 99.2% (876 / 883 lines)
- **Branch Coverage Verified:** 91.9% (395 / 430 branches)
- **Data Isolation:** All tests run within isolated sandbox directories; production data untouched.
