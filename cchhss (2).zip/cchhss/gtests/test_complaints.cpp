#include "test_helpers.h"

using namespace cchhss_test;

class ComplaintsTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 5: findComplaintById TESTS                                       */
/* ========================================================================= */

TEST_F(ComplaintsTest, FindComplaintById_EmptyListReturnsNull) {
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

TEST_F(ComplaintsTest, FindComplaintById_NullOrEmptyIdReturnsNull) {
    EXPECT_EQ(findComplaintById(NULL), nullptr);
    EXPECT_EQ(findComplaintById(""), nullptr);
}

TEST_F(ComplaintsTest, FindComplaintById_FindsHeadAndTailInPopulatedList) {
    // Populate test complaints via data/complaints.txt and initSystem()
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|2026-10-26 10:01:00|2026-10-26 10:01:00|N/A|N/A|N/A|Note 1|Desc 1\n"
        "CMP102|CUST1002|Billing and Account|Low|RESOLVED|AGT102|2026-10-26 11:00:00|2026-10-26 11:01:00|2026-10-26 11:05:00|2026-10-26 11:05:00|N/A|N/A|Note 2|Desc 2\n"
        "CMP103|CUST1001|Logistics Support|Medium|CLOSED|AGT101|2026-10-26 12:00:00|2026-10-26 12:01:00|2026-10-26 12:10:00|2026-10-26 12:10:00|2026-10-26 12:15:00|N/A|Note 3|Desc 3\n";
    writeSandboxFile("data/complaints.txt", compData);

    initSystem();

    // Verify finding head element
    ComplaintNode *headNode = findComplaintById("CMP101");
    ASSERT_NE(headNode, nullptr);
    EXPECT_STREQ(headNode->data.complaintId, "CMP101");
    EXPECT_STREQ(headNode->data.customerId, "CUST1001");

    // Verify finding middle element
    ComplaintNode *midNode = findComplaintById("CMP102");
    ASSERT_NE(midNode, nullptr);
    EXPECT_STREQ(midNode->data.complaintId, "CMP102");

    // Verify finding tail element
    ComplaintNode *tailNode = findComplaintById("CMP103");
    ASSERT_NE(tailNode, nullptr);
    EXPECT_STREQ(tailNode->data.complaintId, "CMP103");

    // Verify not found
    EXPECT_EQ(findComplaintById("CMP999"), nullptr);

    // Verify case sensitivity
    EXPECT_EQ(findComplaintById("cmp101"), nullptr);
}

/* ========================================================================= */
/* FUNCTION 6: addAuditEntry TESTS                                           */
/* ========================================================================= */

TEST_F(ComplaintsTest, AddAuditEntry_NullNodeHandledSafely) {
    addAuditEntry(NULL, "ACTION", "USER", "Details");
    SUCCEED();
}

TEST_F(ComplaintsTest, AddAuditEntry_AppendsToEmptyAuditTrail) {
    // Create complaint record
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Initial|Router issue\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    EXPECT_EQ(node->auditHead, nullptr);

    // Add first entry
    addAuditEntry(node, "REGISTERED", "CUST1001", "Lodged new ticket");
    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->complaintId, "CMP101");
    EXPECT_STREQ(node->auditHead->action, "REGISTERED");
    EXPECT_STREQ(node->auditHead->performedBy, "CUST1001");
    EXPECT_STREQ(node->auditHead->details, "Lodged new ticket");
    EXPECT_EQ(node->auditHead->next, nullptr);
    EXPECT_EQ(strlen(node->auditHead->timestamp), 19u);
}

TEST_F(ComplaintsTest, AddAuditEntry_AppendsMultipleEntriesChronologically) {
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Initial|Router issue\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);

    addAuditEntry(node, "REGISTERED", "CUST1001", "Entry 1");
    addAuditEntry(node, "ASSIGNED", "MANAGER", "Entry 2");
    addAuditEntry(node, "RESOLVED", "AGT101", "Entry 3");

    AuditNode *a1 = node->auditHead;
    ASSERT_NE(a1, nullptr);
    EXPECT_STREQ(a1->action, "REGISTERED");

    AuditNode *a2 = a1->next;
    ASSERT_NE(a2, nullptr);
    EXPECT_STREQ(a2->action, "ASSIGNED");

    AuditNode *a3 = a2->next;
    ASSERT_NE(a3, nullptr);
    EXPECT_STREQ(a3->action, "RESOLVED");
    EXPECT_EQ(a3->next, nullptr);
}

TEST_F(ComplaintsTest, AddAuditEntry_NullFieldsFallbackToDefaults) {
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Initial|Router issue\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);

    // Call with NULL action, by, and details to test ternary branches
    addAuditEntry(node, NULL, NULL, NULL);

    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->action, "ACTION");
    EXPECT_STREQ(node->auditHead->performedBy, "SYSTEM");
    EXPECT_STREQ(node->auditHead->details, "");
}
