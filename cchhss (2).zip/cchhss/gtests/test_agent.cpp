#include "test_helpers.h"

using namespace cchhss_test;

class AgentTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 7: autoAssignAgent TESTS                                         */
/* ========================================================================= */

TEST_F(AgentTest, AutoAssignAgent_AllInactiveReturnsNegativeOne) {
    std::string inactiveAgents;
    for (int i = 0; i < 10; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|agent%d|pass%d|0|0\n", 101 + i, i + 1, i + 1, i + 1);
        inactiveAgents += buf;
    }
    writeSandboxFile("data/agents.txt", inactiveAgents);
    initSystem();

    EXPECT_EQ(autoAssignAgent(), -1);
}

TEST_F(AgentTest, AutoAssignAgent_SelectsAgentWithLeastActiveWorkload) {
    // AGT101 has 2 active tickets (ASSIGNED, IN_PROGRESS) and 1 RESOLVED and 1 CLOSED
    // AGT102 has 1 active ticket (ASSIGNED)
    // AGT103 has 0 active tickets -> AGT103 (index 2) must be chosen!
    std::string compData =
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|D1\n"
        "CMP102|CUST1001|Tech|High|IN_PROGRESS|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|D2\n"
        "CMP103|CUST1001|Tech|High|RESOLVED|AGT101|T1|T2|T3|T4|N/A|N/A|Note|D3\n"
        "CMP104|CUST1001|Tech|High|CLOSED|AGT101|T1|T2|T3|T4|T5|N/A|Note|D4\n"
        "CMP105|CUST1002|Tech|High|ASSIGNED|AGT102|T1|T2|T3|N/A|N/A|N/A|Note|D5\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    int chosenIdx = autoAssignAgent();
    // Since AGT103 (index 2) has 0 active tickets, it should be selected
    EXPECT_EQ(chosenIdx, 2);
}

/* ========================================================================= */
/* FUNCTION 19: agentMenu TESTS                                              */
/* ========================================================================= */

TEST_F(AgentTest, AgentMenu_HandlesAuthenticationFailuresAndInactiveAccounts) {
    // AGT101 active, AGT102 inactive
    std::string agentsData =
        "AGT101|Alice Smith|agent1|pass1|1|0\n"
        "AGT102|Bob Johnson|agent2|pass2|0|0\n";
    for (int i = 2; i < 10; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|agent%d|pass%d|1|0\n", 101 + i, i + 1, i + 1, i + 1);
        agentsData += buf;
    }
    writeSandboxFile("data/agents.txt", agentsData);
    initSystem();

    // 1. Invalid credentials
    {
        ScopedStdin in("1\nagent1\nwrongpass\n2\n");
        ScopedStdout out;
        agentMenu();
        EXPECT_NE(out.getOutput().find("Authentication failed: Invalid agent username or password."), std::string::npos);
    }

    // 2. Inactive account credentials
    {
        ScopedStdin in("1\nagent2\npass2\n2\n");
        ScopedStdout out;
        agentMenu();
        EXPECT_NE(out.getOutput().find("Access denied: Your agent account is currently set to Inactive."), std::string::npos);
    }

    // 3. Successful login then logout
    {
        ScopedStdin in("1\nagent1\npass1\n4\n2\n");
        ScopedStdout out;
        agentMenu();
        std::string output = out.getOutput();
        EXPECT_NE(output.find("Welcome, Alice Smith (AGT101)!"), std::string::npos);
        EXPECT_NE(output.find("AGENT DASHBOARD: Alice Smith (AGT101)"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 20: agentDashboard TESTS                                         */
/* ========================================================================= */

TEST_F(AgentTest, AgentDashboard_Option3AuditHistoryFoundAndNotFound) {
    std::string compData =
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Desc\n";
    std::string auditData =
        "CMP101|2026-10-26 10:00:00|ASSIGNED|SYSTEM|Auto-assigned to AGT101\n";
    writeSandboxFile("data/complaints.txt", compData);
    writeSandboxFile("data/audit_log.txt", auditData);
    initSystem();

    // Sequence testing all agent dashboard menu options:
    // Choice 1 -> View assigned complaints
    // Choice 2 -> Update complaint (CMP101 -> 4 to cancel)
    // Choice 3 -> View history with missing complaint ID -> Error
    // Choice 3 -> View history with existing complaint ID -> Audit table
    // Choice 4 -> Logout
    ScopedStdin in("1\n2\nCMP101\n4\n3\nCMP999\n3\nCMP101\n4\n");
    ScopedStdout out;

    agentDashboard(0); // agent 0 is AGT101
    std::string output = out.getOutput();

    EXPECT_NE(output.find("Assigned Complaints for AGT101"), std::string::npos);
    EXPECT_NE(output.find("Updating Complaint: CMP101"), std::string::npos);
    EXPECT_NE(output.find("Error: Complaint ID 'CMP999' not found."), std::string::npos);
    EXPECT_NE(output.find("Audit History for CMP101"), std::string::npos);
    EXPECT_NE(output.find("Auto-assigned to AGT101"), std::string::npos);
    EXPECT_NE(output.find("Logging out of agent portal..."), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 21: agentViewAssigned TESTS                                      */
/* ========================================================================= */

TEST_F(AgentTest, AgentViewAssigned_ZeroAndPopulatedAssignedComplaints) {
    std::string compData =
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // AGT101 has 1 ticket
    {
        ScopedStdout out;
        agentViewAssigned("AGT101");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("CMP101"), std::string::npos);
        EXPECT_NE(output.find("Total Assigned: 1"), std::string::npos);
    }

    // AGT102 has 0 tickets
    {
        ScopedStdout out;
        agentViewAssigned("AGT102");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("No complaints are currently assigned to you."), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 22: agentUpdateComplaint TESTS                                    */
/* ========================================================================= */

TEST_F(AgentTest, AgentUpdateComplaint_NotFoundAndNotAssignedToAgent) {
    std::string compData =
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT102|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // 1. Complaint not found
    {
        ScopedStdin in("CMP999\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        EXPECT_NE(out.getOutput().find("Complaint ID 'CMP999' not found."), std::string::npos);
    }

    // 2. Complaint assigned to AGT102, but AGT101 attempts update
    {
        ScopedStdin in("CMP101\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        EXPECT_NE(out.getOutput().find("is not assigned to you (Assigned to: AGT102)"), std::string::npos);
    }
}

TEST_F(AgentTest, AgentUpdateComplaint_ActionsAndNotesVerification) {
    std::string compData =
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Initial|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // Case 1: Cancel action (Choice 4)
    {
        ScopedStdin in("CMP101\n4\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        EXPECT_NE(out.getOutput().find("Action cancelled."), std::string::npos);
    }

    // Case 2: Mark IN_PROGRESS with empty note (Choice 1) -> default note
    {
        ScopedStdin in("CMP101\n1\n\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("[SUCCESS] Status updated to IN_PROGRESS."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "IN_PROGRESS");
        EXPECT_STREQ(cmp->data.lastNote, "Status updated by AGT101");
    }

    // Case 3: Mark ESCALATED with custom note (Choice 3)
    {
        ScopedStdin in("CMP101\n3\nEscalating to level 2 network engineering\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("[SUCCESS] Complaint marked as ESCALATED"), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "ESCALATED");
        EXPECT_STREQ(cmp->data.lastNote, "Escalating to level 2 network engineering");
        EXPECT_STRNE(cmp->data.timestamps.escalated, "N/A");
    }

    // Case 4: Mark RESOLVED with custom note (Choice 2)
    {
        ScopedStdin in("CMP101\n2\nReplaced optical switch port\n");
        ScopedStdout out;
        agentUpdateComplaint("AGT101");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("[SUCCESS] Status updated to RESOLVED."), std::string::npos);

        ComplaintNode *cmp = findComplaintById("CMP101");
        ASSERT_NE(cmp, nullptr);
        EXPECT_STREQ(cmp->data.status, "RESOLVED");
        EXPECT_STRNE(cmp->data.timestamps.resolved, "N/A");
    }
}
