#include "test_helpers.h"

using namespace cchhss_test;

class CustomerTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 11: customerMenu TESTS                                           */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerMenu_RoutesToRegisterAndLoginThenExits) {
    initSystem();

    // Choice 1 -> Register (enter blank name to abort register)
    // Choice 2 -> Login (enter invalid credentials to fail login)
    // Choice 3 -> Exit to main menu
    ScopedStdin in("1\n\n2\nfake\nfake\n3\n");
    ScopedStdout out;

    customerMenu();
    std::string output = out.getOutput();

    EXPECT_NE(output.find("CUSTOMER PORTAL"), std::string::npos);
    EXPECT_NE(output.find("Customer Account Registration"), std::string::npos);
    EXPECT_NE(output.find("Customer Login"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 15: customerRegisterComplaint TESTS                              */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerRegisterComplaint_AbortsOnEmptyDescription) {
    initSystem();

    // Category 1, Priority 2, Empty description
    ScopedStdin in("1\n2\n\n");
    ScopedStdout out;

    customerRegisterComplaint("CUST1001");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("Registration aborted: Description cannot be empty."), std::string::npos);
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

TEST_F(CustomerTest, CustomerRegisterComplaint_NormalAutoAssignsActiveAgent) {
    initSystem();

    // Category 1 (Technical Support), Priority 3 (High), Valid description
    ScopedStdin in("1\n3\nFiber internet outage at residence\n");
    ScopedStdout out;

    customerRegisterComplaint("CUST1001");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("[SUCCESS] Complaint Registered Successfully!"), std::string::npos);
    EXPECT_NE(output.find("CMP101"), std::string::npos);
    EXPECT_NE(output.find("Status:             ASSIGNED"), std::string::npos);

    ComplaintNode *cmp = findComplaintById("CMP101");
    ASSERT_NE(cmp, nullptr);
    EXPECT_STREQ(cmp->data.customerId, "CUST1001");
    EXPECT_STREQ(cmp->data.category, "Technical Support");
    EXPECT_STREQ(cmp->data.priority, "High");
    EXPECT_STREQ(cmp->data.status, "ASSIGNED");
    EXPECT_STREQ(cmp->data.assignedAgentId, "AGT101");
    EXPECT_NE(cmp->auditHead, nullptr);
}

TEST_F(CustomerTest, CustomerRegisterComplaint_NoActiveAgentsFallsBackToPending) {
    // Configure all 10 agents to inactive (isActive = 0)
    std::string inactiveAgents;
    for (int i = 0; i < 10; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|agent%d|pass%d|0|0\n", 101 + i, i + 1, i + 1, i + 1);
        inactiveAgents += buf;
    }
    writeSandboxFile("data/agents.txt", inactiveAgents);

    initSystem();

    // Register complaint when no active agents exist
    ScopedStdin in("2\n2\nBilling error dispute\n");
    ScopedStdout out;

    customerRegisterComplaint("CUST1001");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("Pending Manager Assignment"), std::string::npos);

    ComplaintNode *cmp = findComplaintById("CMP101");
    ASSERT_NE(cmp, nullptr);
    EXPECT_STREQ(cmp->data.status, "PENDING");
    EXPECT_STREQ(cmp->data.assignedAgentId, "UNASSIGNED");
    EXPECT_STREQ(cmp->data.timestamps.assigned, "N/A");
}

TEST_F(CustomerTest, CustomerRegisterComplaint_CollisionAvoidanceWhileLoop) {
    initSystem();

    // Register first complaint -> gets CMP101, nextComplaintNum becomes 102
    {
        ScopedStdin in("1\n1\nInitial complaint description\n");
        ScopedStdout out;
        customerRegisterComplaint("CUST1001");
        EXPECT_NE(out.getOutput().find("CMP101"), std::string::npos);
    }

    // In memory, mutate the first complaint's ID to CMP102 to create an intentional collision.
    // When next complaint registers, it generates CMP102, finds the collision, triggers nextComplaintNum++,
    // and successfully claims CMP103!
    ComplaintNode *cmp1 = findComplaintById("CMP101");
    ASSERT_NE(cmp1, nullptr);
    snprintf(cmp1->data.complaintId, sizeof(cmp1->data.complaintId), "CMP102");

    // Register second complaint -> advances past collision to CMP103
    {
        ScopedStdin in("2\n2\nCollision trigger description\n");
        ScopedStdout out;
        customerRegisterComplaint("CUST1001");
        EXPECT_NE(out.getOutput().find("CMP103"), std::string::npos);
    }

    // Register third complaint -> traverses list to tail (exercises curr = curr->next in append loop)
    {
        ScopedStdin in("3\n3\nThird complaint for append traversal\n");
        ScopedStdout out;
        customerRegisterComplaint("CUST1001");
        EXPECT_NE(out.getOutput().find("CMP104"), std::string::npos);
    }

    EXPECT_NE(findComplaintById("CMP102"), nullptr);
    EXPECT_NE(findComplaintById("CMP103"), nullptr);
    EXPECT_NE(findComplaintById("CMP104"), nullptr);
}

/* ========================================================================= */
/* FUNCTION 16: customerViewComplaints TESTS                                 */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerViewComplaints_ZeroComplaintsHandled) {
    initSystem();

    ScopedStdout out;
    customerViewComplaints("CUST1001");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("No complaints found under your account."), std::string::npos);
}

TEST_F(CustomerTest, CustomerViewComplaints_DisplaysOnlyOwnedComplaints) {
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note 1|Alice ticket\n"
        "CMP102|CUST1002|Billing and Account|Low|RESOLVED|AGT102|2026-10-26 11:00:00|N/A|2026-10-26 11:00:00|N/A|N/A|N/A|Note 2|Bob ticket\n"
        "CMP103|CUST1001|Customer Service|Medium|PENDING|UNASSIGNED|2026-10-26 12:00:00|N/A|2026-10-26 12:00:00|N/A|N/A|N/A|Note 3|Alice ticket 2\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    ScopedStdout out;
    customerViewComplaints("CUST1001");
    std::string output = out.getOutput();

    EXPECT_NE(output.find("CMP101"), std::string::npos);
    EXPECT_NE(output.find("CMP103"), std::string::npos);
    EXPECT_EQ(output.find("CMP102"), std::string::npos); // Bob's ticket must not be displayed
    EXPECT_NE(output.find("Total Complaints: 2"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 17: customerTrackComplaint TESTS                                 */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerTrackComplaint_NotFoundAndSecurityViolation) {
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Ticket\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    // 1. Not found
    {
        ScopedStdin in("CMP999\n");
        ScopedStdout out;
        customerTrackComplaint("CUST1001");
        EXPECT_NE(out.getOutput().find("Complaint ID 'CMP999' not found."), std::string::npos);
    }

    // 2. Belongs to CUST1001, requested by CUST1002 (Security violation)
    {
        ScopedStdin in("CMP101\n");
        ScopedStdout out;
        customerTrackComplaint("CUST1002");
        EXPECT_NE(out.getOutput().find("Security violation: You are not authorized"), std::string::npos);
    }
}

TEST_F(CustomerTest, CustomerTrackComplaint_AllStagesProgressionVerification) {
    std::string compData =
        "CMP101|CUST1001|Cat|Pri|PENDING|UNASSIGNED|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n"
        "CMP102|CUST1001|Cat|Pri|ASSIGNED|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n"
        "CMP103|CUST1001|Cat|Pri|IN_PROGRESS|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n"
        "CMP104|CUST1001|Cat|Pri|ESCALATED|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n"
        "CMP105|CUST1001|Cat|Pri|RESOLVED|AGT101|T1|T2|T3|T4|N/A|N/A|Note|Desc\n"
        "CMP106|CUST1001|Cat|Pri|CLOSED|AGT101|T1|T2|T3|T4|T5|N/A|Note|Desc\n"
        "CMP107|CUST1001|Cat|Pri|CUSTOM_STATUS|AGT101|T1|T2|T3|N/A|N/A|N/A|Note|Desc\n";
    writeSandboxFile("data/complaints.txt", compData);
    initSystem();

    const char *cases[][2] = {
        {"CMP101", "[Stage 1/5] Received & Queued for Agent"},
        {"CMP102", "[Stage 2/5] Assigned to Support Agent"},
        {"CMP103", "[Stage 3/5] Active Investigation & Troubleshooting"},
        {"CMP104", "[Stage 3.5/5] Escalated for Senior Technical Review"},
        {"CMP105", "[Stage 4/5] Resolution Provided"},
        {"CMP106", "[Stage 5/5] Formally Closed"},
        {"CMP107", "Current State: CUSTOM_STATUS"}
    };

    for (const auto &tc : cases) {
        ScopedStdin in(std::string(tc[0]) + "\n");
        ScopedStdout out;
        customerTrackComplaint("CUST1001");
        std::string output = out.getOutput();
        EXPECT_NE(output.find(tc[1]), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 18: customerViewHistory TESTS                                    */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerViewHistory_NotFoundSecurityViolationAndAuditRecords) {
    std::string compData =
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-10-26 10:00:00|N/A|2026-10-26 10:00:00|N/A|N/A|N/A|Note|Ticket\n"
        "CMP102|CUST1001|Billing and Account|Low|PENDING|UNASSIGNED|2026-10-26 11:00:00|N/A|2026-10-26 11:00:00|N/A|N/A|N/A|Note|Ticket\n";
    std::string auditData =
        "CMP101|2026-10-26 10:00:00|REGISTERED|CUST1001|Lodged ticket\n";
    writeSandboxFile("data/complaints.txt", compData);
    writeSandboxFile("data/audit_log.txt", auditData);
    initSystem();

    // 1. Complaint not found
    {
        ScopedStdin in("CMP999\n");
        ScopedStdout out;
        customerViewHistory("CUST1001");
        EXPECT_NE(out.getOutput().find("Complaint ID 'CMP999' not found."), std::string::npos);
    }

    // 2. Security violation
    {
        ScopedStdin in("CMP101\n");
        ScopedStdout out;
        customerViewHistory("CUST1002");
        EXPECT_NE(out.getOutput().find("Security violation: You can only view audit history"), std::string::npos);
    }

    // 3. Owned complaint with audit records
    {
        ScopedStdin in("CMP101\n");
        ScopedStdout out;
        customerViewHistory("CUST1001");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("Chronological Audit History: CMP101"), std::string::npos);
        EXPECT_NE(output.find("Lodged ticket"), std::string::npos);
    }

    // 4. Owned complaint with zero audit records
    {
        ScopedStdin in("CMP102\n");
        ScopedStdout out;
        customerViewHistory("CUST1001");
        std::string output = out.getOutput();
        EXPECT_NE(output.find("No audit records found for this complaint."), std::string::npos);
    }
}
