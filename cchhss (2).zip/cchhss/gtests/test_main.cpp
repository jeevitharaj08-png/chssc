#include "test_helpers.h"

using namespace cchhss_test;

class MainFunctionTest : public ComplaintSystemTest {};

/* ========================================================================= */
/* FUNCTION 29: main (app_main) TESTS                                        */
/* ========================================================================= */

TEST_F(MainFunctionTest, Main_ImmediateCleanExitOption4) {
    // Option 4: Clean exit, saves data, releases memory, returns 0
    ScopedStdin in("4\n");
    ScopedStdout out;

    int ret = app_main();
    std::string output = out.getOutput();

    EXPECT_EQ(ret, 0);
    EXPECT_NE(output.find("COMPLAINT HANDLING SYSTEM"), std::string::npos);
    EXPECT_NE(output.find("Saving system state and releasing resources..."), std::string::npos);
    EXPECT_NE(output.find("Thank you for using the Complaint Handling System. Goodbye!"), std::string::npos);
}

TEST_F(MainFunctionTest, Main_RoutesThroughAllPortalMenusBeforeExit) {
    // 1 -> Customer Menu -> 3 Return
    // 2 -> Agent Menu -> 2 Return
    // 3 -> Manager Menu -> 2 Return
    // 4 -> Exit
    ScopedStdin in("1\n3\n2\n2\n3\n2\n4\n");
    ScopedStdout out;

    int ret = app_main();
    std::string output = out.getOutput();

    EXPECT_EQ(ret, 0);
    EXPECT_NE(output.find("CUSTOMER PORTAL"), std::string::npos);
    EXPECT_NE(output.find("AGENT PORTAL"), std::string::npos);
    EXPECT_NE(output.find("MANAGER PORTAL"), std::string::npos);
    EXPECT_NE(output.find("Goodbye!"), std::string::npos);
}

/* ========================================================================= */
/* GOOGLE TEST MAIN ENTRY POINT                                              */
/* ========================================================================= */

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
